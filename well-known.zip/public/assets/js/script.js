
$(document).ready(function() {
    $('.form-second, .form-third').hide();

    $('.form-first .next').click(function() {
        if ($('.form-first select').val() != null && $('.form-first input[placeholder="Enter Industry"]').val() != "" && $('.form-first #countries').val() != null && $('.form-first input[placeholder="Est. Leads"]').val() != "") {
            $('.form-first').animate({
                opacity: 0
            }, 500, function() {
                $('.form-first').slideUp();
                $('.form-second').slideDown().animate({
                    opacity: 1
                }, 500);
            });
        } else {
            alert("Please fill all required fields.");
        }
    });

    $('.form-second .prev').click(function() {
        $('.form-second').animate({
            opacity: 0,
        }, 500, function() {
            $('.form-second').slideUp();
            $('.form-first').slideDown().animate({
                opacity: 1
            }, 500);
        });
    });

    // $('.form-second .next').click(function() {
    //     if ($('.form-second input[placeholder="Name"]').val() != "" && $('.form-second input[placeholder="Email Address"]').val() != "" && $('.form-second input[placeholder="Phone Number"]').val() != "" && $('.form-second input[placeholder="Your Website"]').val() != "") {
    //         $('.form-second').animate({
    //             opacity: 0
    //         }, 500, function() {
    //             $('.form-second').slideUp();
    //             $('.form-third').slideDown().animate({
    //                 opacity: 1
    //             }, 500);
    //         });
    //     } else {
    //         alert("Please fill all required fields.");
    //     }
    // });

});

$('.case-study-item').on('mouseenter', function() {
    $('.case-study-item').removeClass('item-hovered-on');
    $(this).addClass('item-hovered-on');
});

$('.packages-all').on('mouseenter', function() {
    $('.packages-all').removeClass('active-pricing');
    $(this).addClass('active-pricing');
});

$('.secret-item').on('mouseenter', function() {
    $('.secret-item').removeClass('active-secret-item');
    $(this).addClass('active-secret-item');
});

const dropdown = $('.goals-select');
const input = $('.leads');
dropdown.on('change', function() {
  const selectedOption = this.options[dropdown.prop('selectedIndex')].text;
  switch(selectedOption) {
    case 'Lead Generation':
      input.attr('placeholder', 'Est. Leads');
      break;
    case 'Traffic Optimization':
      input.attr('placeholder', 'Est. Web Traffic');
      break;
    case 'Ecommerce Optimization':
      input.attr('placeholder', 'Est. Coversions');
      break;
    case 'Brand Engagement':
      input.attr('placeholder', 'Est. Likes');
      break;
    case 'Appointment Scheduling':
      input.attr('placeholder', 'Est. Appointments');
      break;
    case 'App Downloads':
      input.attr('placeholder', 'Est. Downloads');
      break;
    default:
      input.attr('placeholder', '');
  }
});


$(window).on('load', function() {
    
    $('.banner-section-services').addClass('loaded-service');
    $('.image-banner').addClass('loaded-image-banner');
    // $('.image-banner-case-study-single img').addClass('loaded-single');
    $('.image-banner-case-study-single-rental img').addClass('loaded-single-rental'); 
    // const element = document.querySelector('.before-quote-sign:before');
    // const pseudoElementStyle = getComputedStyle(element, ':before');
    // pseudoElementStyle.content = '“';
    
    $('.clients-testimonials').slick({
      dots: false,
      arrows: false,
      infinite: true,
      speed: 300,
      slidesToShow: 3,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 15000,
      responsive: [
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
      ]
    });
    
    setTimeout(function(){
        // $('.loader-main').addClass('loader-loaded');
        $('.loader-main').fadeOut();
    }, 500);
    
});


// Menu

$('.icon-tablet-menu').on('click',function(){
    $('.links>ul').toggleClass('active-menu');
    $('body').toggleClass('active-menu-body');
    $(this).toggleClass('close-icon-change');
    $('.sub-menu-items').removeClass('submenu-small-screen-open');
})

$('li.sub-menu > a').on('click',function(){
    $('.sub-menu-items').addClass('submenu-small-screen-open');
})

$('.back-icon').on('click',function(){
    $('.sub-menu-items').removeClass('submenu-small-screen-open');
})

$(document).mouseup(function(e){
   var menu = $('.links > ul,.icon-tablet-menu');
   if (!menu.is(e.target) // The target of the click isn't the container.
   && menu.has(e.target).length === 0) // Nor a child element of the container
   {
        $('.links>ul').removeClass('active-menu');
        $('body').removeClass('active-menu-body');
        $('.icon-tablet-menu').removeClass('close-icon-change');
        $('.sub-menu-items').removeClass('submenu-small-screen-open');
   }
});

// Menu

function format(item, state) {
  if (!item.id) {
    return item.text;
  }
  var countryUrl = "https://hatscripts.github.io/circle-flags/flags/";
  var stateUrl = "https://oxguy3.github.io/flags/svg/us/";
  var url = state ? stateUrl : countryUrl;
  var img = $("<img>", {
    class: "img-flag",
    width: 26,
    src: url + item.element.value.toLowerCase() + ".svg"
  });
  var span = $("<span>", {
    text: " " + item.text
  });
  span.prepend(img);
  return span;
}

$("#countries").select2({
    templateResult: function(item) {
      return format(item, false);
    }
});

// Packages Info

$('.packages-all button.btn-regular').on('click',function(){
    var pricing = $(this).closest('.packages-all').find('.pricing-packages p').text();
    var packagename = $(this).closest('.packages-all').find('h3').text();
    $('.price-package').val(pricing);
    $('.package-name').val(packagename);
})



// GSAP


var limitFunc = function(){
    if (window.innerWidth>992){
        
        gsap.registerPlugin(ScrollTrigger);
        
        gsap.timeline({
                scrollTrigger: {
                    trigger: ".section-sgp",
                    start: "center center",
                    end: "bottom top",
                    scrub: true,
                    pin: true
                }
            })
        .from(".width-on-scroll", { width: '100%' });
        
        
        gsap.timeline({
                scrollTrigger: {
                    trigger: ".image-banner-case-study-single",
                    start: "center center",
                    end: "bottom top",
                    scrub: true,
                    pin: true
                }
            })
        .to(".image-banner-case-study-single img", { rotateX: 0 });
        
    }
};

// window.addEventListener("resize", limitFunc);
window.addEventListener("load", limitFunc);





var FuncSliderPackage = function(){
    if (window.innerWidth<992){
        
        $('.col-second-packages .row-services-packages').slick({
            dots: false,
            infinite: true,
            speed: 300,
            slidesToShow: 3,
            slidesToScroll: 1,
            autoplay:true,
            arrows: false,
            responsive: [{
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 2,
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
        
        $('.clients-testimonials').slick("setPosition", 0);
        
    }
    else{
        $('.col-second-packages .row-services-packages').slick('unslick');
        $('.clients-testimonials').slick("setPosition", 0);
    }
};

window.addEventListener("resize", FuncSliderPackage);
window.addEventListener("load", FuncSliderPackage);

$('.col-second-packages .row-services-packages').on('afterChange', function(event, slick, currentSlide, nextSlide){
    $(".packages-all.slick-slide").removeClass('active-pricing');
    $(".packages-all.slick-slide.slick-current.slick-active[aria-hidden='false']").addClass('active-pricing');
});



