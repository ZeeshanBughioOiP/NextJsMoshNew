<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Croexpertz_Blog_table extends Model
{
    use HasFactory;
    protected $connection = 'second_db';
    protected $table = "croexpertz_blog_table";
    // protected $fillable = [
    //     'user_id',
    //     'post_name',
    //     'post_image',
    //     'post_description',
    //     'post_short_description',
    //     'status',
    // ];
}
