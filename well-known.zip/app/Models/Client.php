<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class Client extends Model
{

    protected $connection = 'outsourcing_runtime_crm_main__dashboard_db';
    protected $table = 'client';
    protected $guarded = [];
    public $timestamps = false;

}