<?php

namespace App\Http\Controllers\Links;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use App\Models\Client;
use App\Models\Croexpertz_Blog_table;
use Auth;
use Illuminate\Support\Facades\DB;

class Links extends Controller
{
    
     public function form(Request $request){
        // dd($request);die();
            $ip=$_SERVER['REMOTE_ADDR'];
            $query = @unserialize(file_get_contents('http://ip-api.com/php/' . $ip));
            // try {
            //     DB::connection()->getPdo();
            //     echo "Database connection established successfully.";
            // } catch (\Exception $e) {
            //     die("Could not connect to the database. Error: " . $e->getMessage());
            // }
            // $data = DB::connection('mysql')
            // ->table('client')->where(['client_email' => $request->input('email'), 'brand_id' => 12, 'domain_id' => 23, 'client_status' => 0])->first('client_email');
            $data = DB::connection('mysql')
            ->table('client')->where(['client_email' => $request->input('email'), 'client_status' => 0])->first('client_email');
            //dd($data);die();
            if(!empty($request->input('serviceprice'))){
                $projectPrice = str_replace( '$', '', $request->input('serviceprice'));
                $projectPrice = str_replace( ',', '',$projectPrice);
            }
      
             
            if(empty($request->input('campaign'))){
                $explodeValue=explode('?',request()->input('dat'));
                if(!empty($explodeValue[1])){
                $dat=explode('&',$explodeValue[1]);
                $sourceExplode=explode('=',$dat[0]);
                // dd($dat[]);
                $campaignExplode=explode('=',$dat[1]);
                }
                
                $utm_source=!empty($campaignExplode[1])?$campaignExplode[1]:'';
                $utm_camp=!empty($campaignExplode[1])?$campaignExplode[1]:'';
            }
            
            
            // $domain_id= $query['country']=='United States' || $query['country']=='Canada' ?20:19;
            if (!empty($data)) {
                $contentUpdate =  array(
                    'brand_id' => 12,
                    'domain_id' => 23,
                    'client_name' => $request->input('name'),
                    'client_email' => $request->input('email'),
                    'client_phone_number' => $request->input('phone'),
                    'client_company' => $request->input('company') ?? '',
                    'client_message' => $request->input('message') ?? '',
                    'form_subject' => ($request->input('FormSubject')) ? $request->input('FormSubject') : '',
                    // 'client_password' => $encrypt,
                    'client_country' => $query['country'] ?? '',
                    'client_city' => $query['city'] ?? '',
                    'client_state' => $query['regionName'] ?? '',
                    'client_date' => date("Y-m-d H:i:s") ?? '',
                    'client_division' => $request->input('servicetitle') ?? 'home',
                    'package_price' => $projectPrice??0.00 ,
                    'package_name' => $request->input('servicename') ?? '',
                    'client_campaign' => $request->input('campaign') ?? $utm_camp,
                    'client_source' => $request->input('source') ?? $utm_source
                    
                );
                
                 $result =   DB::connection('mysql')
            ->table('client')->where('client_email', $request->input('email'))->update($contentUpdate);
                 
                if ($result) {
                  
                    $response['msg']  = "Thankyou for updating your details. We will contact you shortly";
                    $response['content'] = $contentUpdate;
                    return response()->json($response);
                    
                }
                
            }else {
                if ($query) {

                    $encrypt = Hash::make($request->input('name'));
                    
                    if($request->input('servicetitle') == 'home'){
                        $message_data = $request->input('message');
                        $all_tags = explode( '|' , $message_data );
                        if(empty($all_tags[1])){
                            $Goal = '';
                             $Leads = '';
                             $Industry = '';
                             $Countries = '';
                             $messages = $request->input('message');
                        }else{
                             $Goals = $all_tags[1];
                             $Leadss = $all_tags[3];
                             $Industrys = $all_tags[5];
                             $Countriess = $all_tags[7];
                             $messages = 'Goal: '.$Goals.' | Leads: '.$Leadss.' | Industry: '.$Industrys.' | Countries: '.$Countriess;
                        }
                    } else if($request->input('servicetitle') == 'contact'){
                        $message_data = $request->input('message');
                        $all_tags = explode( '|' , $message_data );
                        
                        if(empty($all_tags[1])){
                            $messages = $request->input('message');
                        }else{
                            $Services_Of_Interests = $all_tags[1];
                            $sms_contacts = $all_tags[3];
                            $messages = 'Services Of Interest: '.$Services_Of_Interests.' | message: '.$sms_contacts;
                        }
                    } else {
                        $messages = $request->input('message');
                    }
                    
                    $content  =  DB::connection('mysql')
                    ->table('client')
                    ->insert([
                        'brand_id' =>12,
                        'domain_id' => 23,
                        'client_name' => $request->input('name'),
                        'client_email' => $request->input('email'),
                        'client_phone_number' => $request->input('phone'),
                        'client_company' => $request->input('company') ?? '',
                        'client_message' => $messages ?? '',
                        'form_subject' => ($request->input('FormSubject')) ? $request->input('FormSubject') : '',
                        'client_password' => $request->input('name'),
                        'client_country' => $query['country'] ?? '',
                        'client_city' => $query['city'] ?? '',
                        'client_state' => $query['regionName'] ?? '',
                        'client_date' => date("Y-m-d H:i:s") ?? '',
                        'client_division' => $request->input('servicetitle') ?? 'home',
                        'package_price' => $projectPrice??0.00 ,
                        'package_name' => $request->input('servicename') ?? '',
                        'client_website' => $request->input('website_url') ?? '',
                        'client_campaign' => $request->input('campaign') ?? $campaignExplode[1]??'',
                        'client_source' => $request->input('source') ?? $sourceExplode[1]??''
                        
                    ]);
                    
                    
                    if($request->input('servicetitle') == 'contact'){
                        $message_data = $request->input('message');
                        $all_tags = explode( '|' , $message_data );
                        
                        if(empty($all_tags[1])){
                            $Services_Of_Interest = '';
                            $sms_contact = $request->input('message');
                        }else{
                            $Services_Of_Interest = $all_tags[1];
                            $sms_contact = $all_tags[3];
                        }
                        
                        
                        
                        //echo "<pre>";print_r($all_tags[1]);die();
                    } else if($request->input('servicetitle') == 'home'){
                        $message_data = $request->input('message');
                        $all_tags = explode( '|' , $message_data );
                        if(empty($all_tags[1])){
                            $Goal = '';
                             $Leads = '';
                             $Industry = '';
                             $Countries = '';
                             $sms_contact = $request->input('message');
                        }else{
                             $Goal = $all_tags[1];
                             $Leads = $all_tags[3];
                             $Industry = $all_tags[5];
                            $Countries = $all_tags[7];
                             $sms_contact = '';
                        }
                    }
                     $ip = 'IP: ' . $query['query'] . '<br>' . 'ZIP Code: ' . $query['zip'] . '<br>' . $query['country'] . '<br>' . $query['regionName'] . '<br>' . $query['city'] . '<br>' . 'Timezone: ' . $query['timezone'] . '<br>' . 'ISP: ' . $query['isp'] . '<br>' . 'Longitute: ' . $query['lon'] . '<br>' . 'Latitute: ' . $query['lat'];

                    $section = array(
                        'email' => $request->input('email'),
                        'password' => $request->input('name'),
                        'link' => "https://outsourcingprojects.com/dashboard/client-login",

                    );


                    $section = array();
                    if($request->input('servicetitle') == 'contact'){
                        $section = array(
                            'email' => $request->input('email'),
                            'name' => $request->input('name'),
                            'phone' => $request->input('phone'),
                            'service_interest' =>$Services_Of_Interest??'',
                            'sms' =>$sms_contact??'',
                            'package_name'=>$request->input('servicename') ??'',
                            'company'=>$request->input('company')??'',
                            'website_url'=>$request->input('website_url')??'',
                            'package_price'=>$projectPrice??'',
                            'URL' => $request->input('dat')=='/'?'':$request->input('dat'),
                       
                            'ip' => $ip??''
            
                        );
                    } else if($request->input('servicetitle') == 'home'){
                        $section = array(
                            'email' => $request->input('email'),
                            'name' => $request->input('name'),
                            'phone' => $request->input('phone'),
                            'goal' =>$Goal??'',
                            'leads' =>$Leads??'',
                            'industry' =>$Industry??'',
                            'countries' =>$Countries??'',
                            'sms' =>$sms_contact??'',
                            'package_name'=>$request->input('servicename') ??'',
                            'website_url'=>$request->input('website_url')??'',
                            'package_price'=>$projectPrice??'',
                            'URL' => $request->input('dat')=='/'?'':$request->input('dat'),
                       
                            'ip' => $ip??''
    
            
                        );
                    }else{
                        $section = array(
                            'email' => $request->input('email'),
                            'name' => $request->input('name'),
                            'phone' => $request->input('phone'),
                            'sms' =>$request->input('message'),
                            'package_name'=>$request->input('servicename') ??'',
                            'package_price'=>$projectPrice??'',
                            'URL' => $request->input('dat')=='/'?'':$request->input('dat'),
                       
                            'ip' => $ip??''
    
            
                        );
                    }
                    
                      \Mail::send('email.signUp', $section, function ($message) use ($section) {
                                $message->to('info@croxpertz.com')->from($section['email'])
                                    ->subject('Croxpertz');
                            });
                         

                    // if (!empty($content->id)) {
                    if ($request->input('getStartForm')) {
                        if (!empty($content->id)) {
                            return redirect()->back()->with('success', 'We have recieved your message. We will get back to you shortly');
                        }
                    } else {
                        if ($content) {
                            $response['msg']    = "Thankyou for updating your details. We will contact you shortly.";
                            $response['content'] = $content;
                            return response()->json($response);
                        }
                    }
                    
                }
                
            }
    }
    
    public function designer()
    {   
        return view('resources.designer');
    }
    
    public function developer()
    {   
        return view('resources.developer');
    }
    
    public function marketing()
    {   
        return view('resources.marketing');
    }
    
    public function va()
    {   
        return view('resources.va');
    }
    
    
    
    
    
    
    // Digital-Service
    
    public function creative()
    {   
        return view('digital-services.creative');
    }
    
    public function web()
    {   
        return view('digital-services.web');
    }
    
    public function app()
    {   
        return view('digital-services.app');
    }
    
    public function smm()
    {   
        return view('digital-services.smm');
    }
    
    public function lead()
    {   
        return view('digital-services.lead');
    }
    
    public function seo()
    {   
        return view('digital-services.seo');
    }
    
    
    
    
    
    
    // Ecom-Service
    
    public function amazon()
    {   
        return view('ecom-services.amazon');
    }
    
    public function shopify()
    {   
        return view('ecom-services.shopify');
    }
    
    public function marketplace()
    {   
        return view('ecom-services.marketplace');
    }
    
    // Emerging-tech-Service
    
    public function nft()
    {   
        return view('emerging-tech.nft');
    }
    
    public function web03()
    {   
        return view('emerging-tech.web03');
    }
    
    public function blockchain()
    {   
        return view('emerging-tech.blockchain');
    }
    
    public function virtualreality()
    {   
        return view('emerging-tech.virtual-reality');
    }
    
    public function augmentedreality()
    {   
        return view('emerging-tech.augmented-reality');
    }
    
    
    
    // BPO-Service
    
    public function salessupport()
    {   
        return view('bpo.sales-support');
    }
    
    public function functional()
    {   
        return view('bpo.functional');
    }
    
    public function devops()
    {   
        return view('bpo.devops');
    }
    
    
    // BPO-Service
    
    
    // Industry-Plans
    
    public function digitalagency()
    {   
        return view('industry-plans.digital-agency');
    }
    
    public function ecommerce()
    {   
        return view('industry-plans.ecommerce');
    }
    
    public function realestate()
    {   
        return view('industry-plans.real-estate');
    }
    
    public function healthcare()
    {   
        return view('industry-plans.healthcare');
    }
    
    public function cleaning()
    {   
        return view('industry-plans.cleaning');
    }
    
    // 
    
    public function professionalservices()
    {   
        return view('industry-plans.professional-services');
    }
    
    public function vehiclerental()
    {   
        return view('industry-plans.vehicle-rental');
    }
    
    public function lawfirms()
    {   
        return view('industry-plans.law-firms');
    }
    
    public function restaurants()
    {   
        return view('industry-plans.restaurants');
    }
    
    public function financial()
    {   
        return view('industry-plans.financial');
    }
    
    // portfolio
    
     public function bmad()
    {   
        return view('portfolio.bmad');
    }
       public function bata()
    {   
        return view('portfolio.bata');
    }
       public function drink()
    {   
        return view('portfolio.drink');
    }
       public function ocala()
    {   
        return view('portfolio.ocala');
    }
    
    
    // Blogs
    
    // public function blog1(){   
    //     return view('blogs.blog1');
    // }
    // public function blog2(){   
    //     return view('blogs.blog2');
    // }
    // public function blog3(){   
    //     return view('blogs.blog3');
    // }
    
    public function blogs(){  
        $userId = Auth::id(); 
        $data = Croexpertz_Blog_table::orderBy('post_id', 'desc')->paginate(6);
        return view('blogs',['data'=>$data]); 
        
        //return view('blogs.blog1');
    }

    // public function blog1(){  
    //     $userId = Auth::id(); 
    //     $data = Croexpertz_Blog_table::paginate(12);
    //     // ->where("status", "=", 1)
    //     // ->where("user_id", "=", $userId)
    //     // ->get();
    //     return view('blogs.blog1',['data'=>$data]); 
    //     //return view('blogs.blog1');
    // }
    // public function blog2(){   
    //     $userId = Auth::id(); 
    //     $data = Croexpertz_Blog_table::paginate(12);
    //     // ->where("status", "=", 1)
    //     // ->where("user_id", "=", $userId)
    //     // ->get();
    //     return view('blogs.blog1',['data'=>$data]); 
    //     // return view('blogs.blog2');
    // }
    // public function blog3(){   
    //     $userId = Auth::id(); 
    //     $data = Croexpertz_Blog_table::select("*")->paginate(12);
    //     // ->where("status", "=", 1)
    //     // ->where("user_id", "=", $userId)
    //     // ->get();
    //     return view('blogs.blog1',['data'=>$data]); 
    //     // return view('blogs.blog3');
    // }
    public function blogdetail($id){
        $userId = Auth::id(); 
        $data = Croexpertz_Blog_table::select("*")
        ->where("slug_name", "=", $id)
        ->get();
        if(!empty($data[0]->slug_name)){
        $threeBlogs = Croexpertz_Blog_table::select("*")
        ->where("category", "=", $data[0]->category)
        ->take(7)->latest()->get();
            return view('blog.blog1',['data'=>$data,'threeBlogs'=>$threeBlogs]);
           
        }else{
            abort(404);
        }
    }
    
    // Insights
    
    public function jan(){   
        return view('insights.jan');
    }
    
    public function feb(){
        return view('insights.feb');
    }
    
    public function march(){
        return view('insights.march');
    }
    
    
}
