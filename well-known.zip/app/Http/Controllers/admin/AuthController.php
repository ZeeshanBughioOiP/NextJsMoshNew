<?php

namespace App\Http\Controllers\admin;

use App\Models\CroexpertzUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        if (Auth::check()) {
            return  redirect("postlist");
        } else {
            return view('auth.login');
        }
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function registration()
    {
        return view('auth.registration');
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function postLogin(Request $request)
    {


        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        $credentials = $request->only('email', 'password');

        $user = DB::connection('second_db')
            ->table('croexpertz_users')
            ->where('email', $credentials['email'])
            ->first();
            if ($user) {
                if (Hash::check($credentials['password'], $user->password)) {
                    Auth::loginUsingId($user->id);
                return redirect()->intended('postlist')
                    ->withSuccess('You have Successfully loggedin');
            }
        }

        // if (Auth::attempt($credentials)) {
        //     return redirect()->intended('postlist')
        //     ->withSuccess('You have Successfully loggedin');
        // }

        return redirect("blogadmin")->withSuccess('Oppes! You have entered invalid credentials');
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function postRegistration(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'userrole' => 'required',
        ]);

        $data = $request->all();
        $check = $this->create($data);

        return redirect("addpost")->withSuccess('Great! You have Successfully loggedin');
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function dashboard()
    {
        if (Auth::check()) {
            return view('Admin.dashboard');
        }

        return redirect("blogadmin")->withSuccess('Opps! You do not have access');
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function create(array $data)
    {
        return CroexpertzUser::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'userrole' => $data['userrole'],

        ]);
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function logout()
    {
        Session::flush();
        Auth::logout();

        return Redirect('blogadmin');
    }
}
