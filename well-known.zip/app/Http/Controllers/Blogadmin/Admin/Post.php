<?php
  
namespace App\Http\Controllers\Blogadmin\Admin;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use App\Models\Croexpertz_Blog_table;
use Hash;
use Validator;
use DB;

class Post extends Controller
{
    public function index()
    {
        
        if(Auth::check()){
        return view('Admin.addpost');
        }else{
          return view('auth.login');
        }
    }

    public function savepost(Request $request)
    {
        $userId = Auth::id(); 
        $validator = Validator::make($request->all(),[
            'post_name' => 'required',
            'post_description' => 'required',
            'post_short_description' => 'required',
            'category' => 'required',
        ]);


        $result_img1="";
        
        if(!empty($request->image))
        {
            // $result_img1 = $request->file('image')->store('/images');

                $driver_license_file = time() . '_' . $request->file('image')->getClientOriginalName();
                //            $product_image_first_path = $request->file('product_image_first')->storeAs('products', $product_image_first);
                $request->file('image')->move(public_path() . '/uploads/apifileregistration/', $driver_license_file);
               
          
            
        }

            $post = new Croexpertz_Blog_table;
            $post->user_id = $userId;
            $post->post_name = $request->post_name;
            $post->slug_name = $request->slug_name;
            $post->post_short_description = $request->post_short_description;
            $post->post_description = $request->post_description;
            $post->meta_title = $request->meta_title;
            $post->meta_keyword = $request->meta_keyword;
            $post->meta_description = $request->meta_description;
            $post->category = $request->category;
            $post->post_image = $driver_license_file;
            $post->status = 1;
            $post->save();
            // echo "working"; die();
         return redirect('postlist')->with('status', 'Post data has been inserted');
        
    }

    public function postlist()
    {
        if(Auth::check()){
        $userId = Auth::id(); 
        $data = Croexpertz_Blog_table::select("*")
        ->where("status", "=", 1)
        ->where("user_id", "=", $userId)
        ->orderby('post_id','desc')
        ->get();
        

        return view('Admin.postlist',['data'=>$data]);
      }else{
          return view('auth.login');
      }
        
        
    }

    public function post_delete($id)
    {
        $data=DB::table('croexpertz_blog_table')->where('post_id', $id)->delete();
        return redirect('postlist')->with('status', 'Post Has been deleted successfully');
    }

    public function post_edit($id)
    {
        
        $data = Croexpertz_Blog_table::select("*")
        ->where("post_id", "=", $id)
        ->get();

        return view('Admin/postedit',['data'=>$data]);
    }
    public function postupdate(Request $request)
    {
        $id = $request->id;

        if(!empty($request->image))
        {

                $driver_license_file = time() . '_' . $request->file('image')->getClientOriginalName();
                $request->file('image')->move(public_path() . '/uploads/apifileregistration/', $driver_license_file);
               

                $data = array(
                    'post_name'=> $request->post_name,
                    'slug_name' => $request->slug_name,
                    'post_description'=> $request->post_description,
                    'post_short_description' => $request->post_short_description,
                    'meta_title' => $request->meta_title,
                    'meta_keyword' => $request->meta_keyword,
                    'meta_description' => $request->meta_description,
                    'category' => $request->category,
                    'post_image'=> $driver_license_file,
                );

                $update = \DB::table('croexpertz_blog_table') 
                ->where('post_id', $id)
                ->update($data);

            
        }else{
                $data = array(
                    'post_name'=> $request->post_name,
                    'slug_name' => $request->slug_name,
                    'post_description'=> $request->post_description,
                    'post_short_description'=> $request->post_short_description,
                    'meta_title' => $request->meta_title,
                    'meta_keyword' => $request->meta_keyword,
                    'meta_description' => $request->meta_description,
                    'category' => $request->category,
                );

                $update = \DB::table('croexpertz_blog_table') 
                    ->where('post_id', $id)
                    ->update($data);
        }

        return redirect('postlist')->with('status', 'Post Has been Updated successfully');

    }

    public function allpostlist()
    {
        $data = Croexpertz_Blog_table::select("*")
        ->get();

        return view('Admin/allpost',['data'=>$data]);
    }
    public function disapproved($id)
    {
        $data = array(
            'status'=> 0
        );

        $update = \DB::table('croexpertz_blog_table') 
            ->where('post_id', $id)
            ->update($data);

        return redirect('allpostlist')->with('status', 'Post Disapproved successfully');
    }

    public function approved($id)
    {
        $data = array(
            'status'=> 1
        );

        $update = \DB::table('croexpertz_blog_table') 
            ->where('post_id', $id)
            ->update($data);

        return redirect('allpostlist')->with('status', 'Post Approved successfully');
    }
}