<?php
  
namespace App\Http\Controllers;
  
use Illuminate\Http\Request;
use App\Models\Croexpertz_Blog_table;
  
class SitemapController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index($value='')
    {
         //echo"working"; die();
        $posts = Croexpertz_Blog_table::latest()->get();
  
        return response()->view('sitemap', [
            'posts' => $posts
        ])->header('Content-Type', 'text/xml');
    }
}