<div class="social-banner <?php echo $__env->yieldContent('social-icon-main'); ?>">
    <a href="https://www.facebook.com/profile.php?id=100091206667713">
        <img src="<?php echo e(asset('assets/image/social/fb.png')); ?>" alt="">
        <span>Facebook</span>
    </a>
    <a href="https://www.instagram.com/croxpertz/">
        <img src="<?php echo e(asset('assets/image/social/insta.png')); ?>" alt="">
        <span>Instagram</span>
    </a>
    <!--<a href="#">-->
    <!--    <img src="<?php echo e(asset('assets/image/social/twitter.png')); ?>" alt="">-->
    <!--    <span>Twitter</span>-->
    <!--</a>-->
</div><?php /**PATH /home2/croxpertz/public_html/resources/views/socialicons.blade.php ENDPATH**/ ?>