

<?php $__env->startSection('title',$data[0]->meta_title); ?>
<?php $__env->startSection('metakeywords',$data[0]->meta_keyword); ?>
<?php $__env->startSection('metadescription',$data[0]->meta_description); ?>
<?php $__env->startSection('class','blog-detail headerFull'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('class-body','no-overflow-for-sticky'); ?>
    
  
        <section class="position-relative our-blogs py-5">
        <div class="container-1470">
            <div class="row">
                <div class="col-lg-8">
                    <section class="banner-blogs">
                        <div class="banner-blogs-img-details">
                            <img src="<?=url('uploads/apifileregistration/'.$data[0]->post_image); ?>" alt="">
                        </div>
                        <!--<div class="container-1470">-->
                        <!--    <h1 class="fa-90 text-white line-height-104 letter-spacing-5 position-relative d-inline-block"><?=$data[0]->post_name; ?></h1>-->
                        <!--</div>-->
                    </section>
                    <div class="blog-details">
                        <h1 class="fa-90 line-height-112 mb-4 letter-spacing-4 position-relative d-inline-block"><?=$data[0]->post_name; ?></h1>
                        <?=$data[0]->post_description; ?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="follow-us-blogs">
                            <div class="social-links flex-column align-items-start">
                                <h5>Follow Us</h5>
                                <div class="social-links-wrap">
                                    <a href="https://www.facebook.com/profile.php?id=100091206667713" class="social-link fb-link"><i class="fa-brands fa-facebook-f"></i></a>
                                    <a href="https://www.instagram.com/croxpertz/" class="social-link insta-link"><i class="fa-brands fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    <div class="sticky-recent-posts">
                        <div class="box-blogs-recent">
                            <div class="row">
                            <div class="col-lg-12">
                                <h3>Recent Posts</h3>
                            </div>
                            <?php 
                                foreach($threeBlogs as $d){
                                ?>
                                <div class="col-lg-12 mbblogs-50">
                                    <div class="blogs-box">
                                        <a href="<?php echo e(url('/'.$d->slug_name)); ?>">
                                        <!--<img src="<?=url('uploads/apifileregistration/'.$d->post_image); ?>">-->
                                            <div class="pb-0">
                                                <h2><?=$d->post_name; ?></h2>
                                                <p>Posted on: <?php echo e($d->created_at->format('j-F-Y')); ?></p>
                                                <!--<span>Read More</span>-->
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/blog/blog1.blade.php ENDPATH**/ ?>