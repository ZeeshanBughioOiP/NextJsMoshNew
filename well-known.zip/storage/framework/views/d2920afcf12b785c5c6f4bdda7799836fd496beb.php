<html>
    <head>
        <title>Croxpertz</title>
    </head>
<body>
    <div class="container">
        <div>
            <h5>Auto genereated email from Croxpertz </h5><br>
        </div>
        
        <div class="col-md-4">
            <div class="form-group">
                <label>Name</label> : <span><?php echo e($name??''); ?></span>
          

            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>User Id</label> : <span><?php echo e($email??''); ?></span>
          

            </div>
        </div>
        <!--<div class="col-md-4">-->
        <!--    <div class="form-group">-->
        <!--        <label>password</label> : <span><?php echo e($password??''); ?></span>-->
             
        <!--    </div>-->
        <!--</div>-->

        <div class="col-md-4">
            <div class="form-group">
                <label>Phone</label>:<span><?php echo e($phone??''); ?></span>
               
            </div>
        </div>
        <?php if(!empty($sms)){ ?>
        <div class="col-md-4">
            <div class="form-group">
                <label>Message</label>:<span><?php echo e($sms??''); ?></span>
               
            </div>
        </div>
        <?php } ?>
        <?php if(!empty($service_interest)){ ?>
        <div class="col-md-4">
            <div class="form-group">
                <label>Services Of Interest</label>:<span><?php echo e($service_interest??''); ?></span>
               
            </div>
        </div>
        <?php } ?>
        
        <?php if(empty($sms)){ ?>
        <div class="col-md-4">
            <div class="form-group">
                <label>Goal</label>:<span><?php echo e($goal??''); ?></span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Leads</label>:<span><?php echo e($leads??''); ?></span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Industry</label>:<span><?php echo e($industry??''); ?></span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Countries</label>:<span><?php echo e($countries??''); ?></span>
               
            </div>
        </div>
        <?php } ?>
        
          <div class="col-md-4">
            <div class="form-group">
                <label>Package Name</label> : <span><?php echo e($package_name??''); ?></span>
               
            </div>
        </div>
        
         <div class="col-md-4">
            <div class="form-group">
                <label>Package Price</label>  : <span><?php echo e($package_price??''); ?></span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Company Name:</label>  : <span><?php echo e($company??''); ?></span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Website url</label>  : <span><?php echo e($website_url??''); ?></span>
               
            </div>
        </div>
        
        
        
         <div class="col-md-4">
            <div class="form-group">
                <label>URL</label> : <span><?php echo e('https://croxpertz.com'.$URL??''); ?></span>
               
            </div>
        </div>


        <!--<div class="col-md-4">-->
        <!--    <div class="form-group">-->
        <!--        <label>Link</label><span><?php echo e($link??''); ?></span>-->
               
        <!--    </div>-->
        <!--</div>-->

       

        <div class="col-md-4">
            <div class="form-group">
                <label>Ip</label><span><?php echo $ip; ?></span>
               
            </div>
        </div>



    </div>
</body>

</html><?php /**PATH /home2/croxpertz/public_html/resources/views/email/signUp.blade.php ENDPATH**/ ?>