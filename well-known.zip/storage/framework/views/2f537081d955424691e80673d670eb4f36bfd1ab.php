
<?php $__env->startSection('title','Atlas'); ?>
<?php $__env->startSection('metadescription',''); ?>
<?php $__env->startSection('keywords', ''); ?>
<?php $__env->startSection('content'); ?>


        <section class="banner-section-case-studies">
            <div class="container-1470">
                <div class="text-case-studies">
                    <h5 class="bg-gradient-orange">Case Study</h5>
                    <div class="image-banner-case-study-single">
                        <h3>Atlas Digital</h3>
                        <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/atlas-digital/banner.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </section>

        <section class="case-studies-single-about">
            <div class="container-1470">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="text-case-study-single">
                            <h4>What exactly is <br>Atlas Digital?</h4>
                            <p>Atlas Digital is a full-service digital agency that specializes in providing a range of digital solutions to businesses of all sizes. Their team comprises experts in various fields, including digital marketing, creative designing, web development, video development, and app development.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="image-about-single">
                            <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/atlas-digital/about.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="case-studies-challenge">
            <div class="container-1470">
                <div class="case-challenge-row">
                    <div class="image-challenge">
                        <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/atlas-digital/challenge.png')); ?>" alt="">
                    </div>
                    <div class="text-challenge">
                        <div class="portion-challenge bg-blue-gradient-challenge text-white">
                            <h3 class="before-number fa-50">The Challenge</h3>
                            <p>The digital agency market is highly competitive, and standing out from the competition can be a challenge. Atlas Digital needed to differentiate themselves from other digital agencies and highlight their unique selling points to attract clients. We need to convince them of their value proposition, and build their business in a competitive market.</p>
                            <p>Overall, these challenges are significant, but with our strong commitment to delivering high-quality services and building strong relationships with them, Atlas Digital establish as a reputable and successful digital agency in the market.</p>
                        </div>
                        <div class="portion-challenge">
                            <h3 class="before-number number-2 fa-50">The Client</h3>
                            <p>Clients expect us to provide strategic guidance and planning to help them identify their digital marketing goals, target audience, and the best strategies to achieve their goals and provide creative and effective designs for websites and mobile app solutions. Their expectations are detailed analytics and reporting to help them measure the success of their digital marketing efforts and identify areas for improvement. </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="case-study-wwd">
            <div class="container-1470">
                <div class="text-wwd">
                    <h3 class="before-number number-3 fa-50">What we did.</h3>
                    <p>As a digital agency, we strive to meet our client's expectations and help them achieve their business goals through our services. Clients expect clear and timely communication throughout the project. We hold regular meetings to review progress and discuss any concerns the client may have. To meet this expectation, we develop a detailed project plan that includes timelines, milestones, and budgets. Overall, our goal is to understand our client's needs and expectations and deliver solutions that meet their business goals and drive results.</p>
                </div>
                <div class="wwd-img">
                    <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/atlas-digital/whatwedid.png')); ?>" alt="">
                </div>
            </div>
        </section>

        <section class="case-study-single-services">
            <div class="container-1470">
                <div class="case-study-single-services-text">
                    <h4 class="fa-50">Our extreme focus on <br>delightful user experience</h4>
                    <p class="fa-18">We created high-quality, informative content that would attract potential clients to the website and their social media channels. The content was optimized for search engines and highlighted Atlas Digital's services and expertise. </p>
                    <p class="fa-18">We implemented a loyalty program that offered rewards and incentives to clients who continued to work with Atlas Digital. The loyalty program helped to sustain existing clients and encourage them to refer others, leading to an increase in new clients.</p>
                </div>
            </div>
            <div class="service-case-study">
                <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/atlas-digital/services.png')); ?>" alt="">
            </div>
        </section>

        <section class="sec-conclusion">
            <div class="container-1470">
                <h4 class="fa-50 mb-20">Conclusion</h4>
                <div class="conclusion-portion">
                    <div>
                        <p class="fa-18">Through a combination of search engine optimization (SEO), social media marketing, content marketing, and website design and development, we were able to increase Atlas Digital's online visibility, attract more qualified leads, and ultimately drive more revenue to their business.</p>
                        <p class="fa-18">Overall, our partnership with Atlas Digital was a resounding success. We were able to help them achieve their goals and solidify their position as a leading digital agency in their market. </p>
                    </div>
                    <img src=" <?php echo e(asset('assets/image/casestudies/quoteimage.png')); ?>" alt="">
                </div>
            </div>
        </section>

        <section class="amplify-section">
            <div class="container-1470">
                <h3 class="fa-50 text-center mb-5">Similar Case Studies</h3>
                <div class="row">
                    <div class="col-md-6">
                        <div class="amplify-item orange-bg">
                            <h6>Ztech Design</h6>
                            <a class="btn-regular" href="<?php echo e(URL::to('/ztechdesign')); ?>">
                                <span>Have a look</span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="amplify-item blue-bg">
                            <h6>Vital Rental</h6>
                            <a class="btn-regular orange-btn" href="<?php echo e(URL::to('/vitalrental')); ?>">
                                <span> Have a look </span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/atlas.blade.php ENDPATH**/ ?>