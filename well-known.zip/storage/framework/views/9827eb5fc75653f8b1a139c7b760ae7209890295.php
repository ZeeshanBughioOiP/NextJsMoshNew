

<?php $__env->startSection('title','Refund Policy'); ?>
<?php $__env->startSection('metadescription',''); ?>
<?php $__env->startSection('keywords', ''); ?>
<?php $__env->startSection('content'); ?>

        <section class="banner-section-services background-after-image-blurred banner-privacy">
            <div class="before-image-banner position-relative">
                <a href="#sec2" class="secdown">
                    <p>Scroll to explore</p>
                    <span><img src="<?php echo e(asset('assets/image/ArrowULeftDown.png')); ?>" alt=""></span>
                </a>
                <div class="container-1470 position-relative">
                    <div class="banner-flex">
                        <div class="image-banner-left image-banner">
                            <img src=" <?php echo e(asset('assets/image/refund2.png')); ?>" alt="">
                        </div>
                        <div class="banner-content-services">
                            <div>
                                <h1>Refund <br>Policy</h1>
                                <p>We strive to make sure our customers are completely satisfied with their purchase. If you need to request a refund, please contact us and we'll do our best to help you.</p>
                                <a class="btn-regular orange-btn btn-weight-medium" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                                <?php echo $__env->make('socialicons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="image-banner-right image-banner">
                            <img src=" <?php echo e(asset('assets/image/refund.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="sec2" class="pptcrf">
            <div class="container-1470">
                <div class="wrapping">
                     <h2 class="mb-20 fa-50">Refund policy will be voided if,</h2>
            <ul class="fa-18 for-list mb-20">
                <li>A discounted package has been chosen.</li>
                <li>The primary design concept has been approved.</li>
                <li>You have demanded revisions.</li>
                <li>Urgent design projects are non-refundable.</li>
                <li>The cancellation has been made due to reasons non-related to the company.</li>
                <li>The client is unresponsive or out of contact for more than 2 weeks of project.</li>
                <li>Company’s policies, or policy, have been violated.</li>
                <li>Other company or designer has been approached for the same project.</li>
                <li>The creative brief is lacking in required information.</li>
                <li>A complete design change has been demanded.</li>
                <li>The claim has crossed the given ‘request for refund’ time span.</li>
                <li>The business is closing or changing name or business.</li>
                <li>Reasons such as ‘change of mind’, ‘disagreement with partner’ or other reasons that do not pertain to the service will not be subject to refund under any circumstances.</li>
                <li>12% processing fee will be applicable to all the refunds requested from client side.</li>
                <li>No refund can be claimed/processed once after the final files have been delivered to you following your request.</li>
                <li>Refund and revision explicitly does not apply on items offered free.</li>
                <li>Services including but not limited to Social Media, SEO, Domain Registration and Web Hosting are not entitled to refund under any circumstances.</li>
                <li>In case of websites, refunds will not be entertained once the client has approved the design and the website is sent for development.</li>
                <li>In case of logo, refunds will not be entertained once client has shared positive feedback on revisions and design is sent for final files.</li>
                <li>Refund will not be applicable on the work outsourced by third party.</li>
            </ul>
            
            <h2 class="mb-20 fa-50 pdt-50">Amazon Refund Policy:</h2>
            <ul class="fa-18 for-list mb-20">
                <li>Client is eligible to submit refund request in case of service delivery failure from Service Provider if all the Pre-requisites were provided by the client in due time.</li>
                <li>Refund is not applicable if Client fails to fulfill what is required (Business Information, Personal Information, Store Information and Essential Required Data and Documents) after the contract has been made and work has been started.</li>
                <li>Service Provider is not responsible for any mishap occurs due to Client’s bad history of business on amazon, leading to Account Suspension.</li>
                <li>Refund request will be processed within 30 working days when it is requested. (If applicable)</li>
            </ul>
            
        </div>
                    

                

                </div>
                </div>
              
              

        </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/refundpolicy.blade.php ENDPATH**/ ?>