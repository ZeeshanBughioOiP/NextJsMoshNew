

<?php $__env->startSection('title','Case Studies'); ?>
<?php $__env->startSection('metadescription',''); ?>
<?php $__env->startSection('keywords', ''); ?>
<?php $__env->startSection('content'); ?>

        <section class="banner-section-case-studies">
            <div class="container-1470">
                <div class="text-case-studies">
                    <h5 class="bg-gradient-orange">Case Studies</h5>
                    <h4>We are shifting the <br>horizon of technology & <br>building a new future</h4>
                </div>
            </div>
        </section>

        <section class="certification-sec py-0">
            <div class="container-1470">
                <h6>Our Projects</h6>
            </div>
        </section>

        <section class="case-studies-main-page">
            <div class="container-1470">
                <div class="item-case-study-preview">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="case-study-preview-item">
                                <h6>Digital Agency</h6>
                                <h2>Atlas Digital</h2>
                                <p>Atlas Digital is a full-service digital agency that specializes in providing a range of digital solutions to businesses of all sizes. Their team comprises experts in various fields, including digital marketing, creative designing, web development, video development, and app development.</p>
                                <a href="<?php echo e(URL::to('/atlas')); ?>" class="btn-regular orange-btn btn-weight-medium">
                                    <span> Have a look </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="image-preview-case-study">
                                <img src=" <?php echo e(asset('assets/image/casestudies/atlas.png')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item-case-study-preview">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="case-study-preview-item">
                                <h6>Car Renting</h6>
                                <h2>Vital Rental</h2>
                                <p>Vital Rental is a popular car rental service in Australia that operates 24/7, providing customers with flexible and convenient options. They offer an extensive range of vehicles, including cars, and SUVs. Their affordable pricing and customer-friendly policies make them a top choice for rentals.</p>
                                <a href="<?php echo e(URL::to('/vitalrental')); ?>" class="btn-regular orange-btn btn-weight-medium">
                                    <span> Have a look </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="image-preview-case-study bg-yellow">
                                <img src=" <?php echo e(asset('assets/image/casestudies/vitalrenting.png')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item-case-study-preview">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-6">
                            <div class="case-study-preview-item">
                                <h6>Digital Agency</h6>
                                <h2>Ztech Design</h2>
                                <p>Ztech is a digital agency that specializes in providing a range of services such as Social Media Marketing, Web Development, SEO, Google Ads, and Creative Designing. Ztech is focused on helping businesses establish their digital presence, improve their online visibility, and achieve their goals through innovative and effective digital solutions.</p>
                                <a href="<?php echo e(URL::to('/ztechdesign')); ?>" class="btn-regular orange-btn btn-weight-medium">
                                    <span> Have a look </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="image-preview-case-study">
                                <img src="<?php echo e(asset('assets/image/casestudies/ztech.png')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="amplify-section">
            <div class="container-1470">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="amplify-item orange-bg">
                            <h6>Let's <br>Talk<br>  Results!</h6>
                            <a class="btn-regular" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                <span> Get Started </span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="amplify-item blue-bg">
                            <h6>Let's <br>Talk<br>  Numbers!</h6>
                            <a class="btn-regular orange-btn" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                <span> Get Started </span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/casestudies.blade.php ENDPATH**/ ?>