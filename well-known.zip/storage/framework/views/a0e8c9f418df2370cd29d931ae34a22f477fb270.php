

<?php $__env->startSection('title','Qualified Lead Generation Services'); ?>
<?php $__env->startSection('metadescription',"From affordable lead generation services and solutions to nurturing and qualified lead, we've got the winning plan for your business's growth. Contact us for more detail."); ?>
<?php $__env->startSection('keywords', 'lead generation services,lead generation solutions,lead generation platforms,lead generation campaign plan,affordable lead generation services,qualified lead generation services,Lead nurturing services'); ?>
<?php $__env->startSection('content'); ?>



        <section class="banner-section-services background-after-image-blurred">
            <div class="before-image-banner position-relative">
                <a href="#sec2" class="secdown">
                    <p>Scroll to explore</p>
                    <span><img src="<?php echo e(asset('assets/image/ArrowULeftDown.png')); ?>" alt=""></span>
                </a>
                <div class="container-1470 position-relative">
                    <div class="banner-flex">
                        <div class="image-banner-left image-banner">
                            <img src="<?php echo e(asset('assets/image/services/leadgeneration/banner-bottom.png')); ?>" alt="">
                        </div>
                        <div class="banner-content-services">
                            <div>
                                <h1>Lead <br> Generation</h1>
                                <p>CROXpertz understands the complexities of lead generation platforms and focuses on customers who visit your website and convert them into valuable leads. Our data-driven methods, expert insights, and personalized strategies will help you unlock the true potential of your business and drive significant improvements in conversion rates..</p>
                                <a class="btn-regular orange-btn btn-weight-medium" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                                <?php echo $__env->make('socialicons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="image-banner-right image-banner">
                            <img src=" <?php echo e(asset('assets/image/services/leadgeneration/banner-top.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="info-service-page" id="sec2">
            <div class="container-1470">
                <div class="text-service-information">
                    <h4 class="fa-50">Lead Generation solutions for triggering hyper-growth</h4>
                    <p class="fa-18">We devote our expertise to providing you the qualified lead-generation services using the most recent, effective, and tested marketing techniques. Our CRO experts can significantly improve overall lead-generation efforts and drive better results that lead to increased growth and success</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Planning & <br>Research</h4>
                                <div class="image-blurb-item">
                                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/planning.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src=" <?php echo e(asset('assets/image/services/leadgeneration/planning.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Our team creates individualized lead-generation campaign plans that are suited to the particular requirements and preferences of each client after conducting thorough market research and determining the intended audience.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Landing Page <br>Development</h4>
                                <div class="image-blurb-item">
                                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/landing.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src=" <?php echo e(asset('assets/image/services/leadgeneration/landing.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Our expert marketers will design an effective landing page for lead generation that facilitates you to track audience touch points and gather the necessary data about your leads.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Integrations</h4>
                                <div class="image-blurb-item">
                                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/integration.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src=" <?php echo e(asset('assets/image/services/leadgeneration/integration.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Our lead generation solutions help businesses in integrating a variety of tracking tools to quantify and retarget interested audiences which helps increase conversion rates.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Targeting</h4>
                                <div class="image-blurb-item">
                                    <img src="  <?php echo e(asset('assets/image/services/leadgeneration/targeting.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src=" <?php echo e(asset('assets/image/services/leadgeneration/targeting.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>By identifying and targeting the most promising prospects. We boost the probability that they become paying customers and achieve the maximum return on investment of our marketing campaigns.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Campaign <br>Execution</h4>
                                <div class="image-blurb-item">
                                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/campaign.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src=" <?php echo e(asset('assets/image/services/leadgeneration/campaign.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Our team develops campaigns using a combination of innovation, strategic thinking, and data analysis, by successfully implementing them, we produce high-quality leads that are nurtured into paying customers.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Leads</h4>
                                <div class="image-blurb-item">
                                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/leads.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src=" <?php echo e(asset('assets/image/services/leadgeneration/leads.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>For companies looking to increase their revenue, our business is a top supplier of high-quality lead generation services. We have created a tested methodology for generating leads that become clients.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="tools-technology">
            <div class="container-1470">
                <div class="text-service-information">
                    <h4 class="fa-50">Tools and technologies deployed for Lead Generation Service</h4>
                    <p class="fa-18">To ensure efficient lead nurturing and conversion, we leverage our expertise across multiple platforms, tailored to your specific conversion goals and market size. We aim to drive tangible results and foster significant business growth for your company.</p>
                </div>
                <div class="tools-icons">
                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/fb.png')); ?>" alt="">
                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/instagram.png')); ?>" alt="">
                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/linkedin.png')); ?>" alt="">
                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/snapchat.png')); ?>" alt="">
                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/googleads.png')); ?>" alt="">
                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/twitter.png')); ?>" alt="">
                    <img src=" <?php echo e(asset('assets/image/services/leadgeneration/tiktok.png')); ?>" alt="">
                </div>
            </div>
        </section>

        <section class="experience-text">
            <div class="container-1470">

                <div class="text-service-information">
                    <h4 class="fa-50">Elevate your sales growth with our lead generation services</h4>
                    <p class="fa-18">Leverage our affordable lead generation services to lead your business toward profitability. Our experts are enthusiastic about collaborating with you and sharing their specialized skills in bringing together qualified leads.</p>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience">
                            <h4 class="bg-gradient-blue">Market Research</h4>
                            <p>Utilizing a variety of research methodologies, we carry out an in-depth market analysis. You can effectively comprehend your intended audience with the assistance of our market research services.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience">
                            <h4 class="bg-gradient-orange">Website Revamp</h4>
                            <p>It is important to leave your visitors with lasting impressions. Our web services will help you draw in more visitors, keep them interested and turn them into devoted customers.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience">
                            <h4 class="bg-gradient-blue">Advertisement</h4>
                            <p>Our company specializes in producing ads for lead generation that support businesses in bringing in clients and boosting sales. We provide a variety of ad formats, like text, video, images, and more.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience">
                            <h4 class="bg-gradient-orange">Platforms</h4>
                            <p>Social media and search platforms offer a great way to connect with potential customers and have meaningful conversations with them. Our team is specialized in lead generation through different mediums.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience">
                            <h4 class="bg-gradient-blue">Lead Nurturing</h4>
                            <p>Only a limited amount of your leads will be prepared to make a purchase right away. With our lead nurturing services, businesses can turn leads into paying clients.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience">
                            <h4 class="bg-gradient-orange">Monthly Report</h4>
                            <p>We track and analyze your data using advanced analytics tools so that we can give our customers detailed, easy-to-understand monthly reports that show trends and insights in their lead data.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <section class="pricing-services">
            <div class="container-1470">
                <div class="text-pricing">
                    <h4>Monthly Retainer <br> Plans</h4>
                    <p class="mx-663">With our monthly retainer plan, you can rest assured that your company is in the hands of knowledgeable professionals.</p>
                </div>
                <div class="package-main-services">
                    <div class="main-parent-services-packages">
                        <div class="row-services-packages">
                            <div class="col-first-packages">
                                <h3>Deliverables</h3>
                                <ul class="features-li line-before">
                                    <li>Research</li>
                                    <li>Website Revamp</li>
                                    <li>Landing Page</li>
                                    <li>Text Ad</li>
                                    <li>Image Ad</li>
                                    <li>Video Ad</li>
                                    <li>Ad Type</li>
                                    <li>Platforms</li>
                                    <li>Integrations</li>
                                    <li>Campaign Management</li>
                                    <li>Ad Budget Included</li>
                                    <li>Est. Leads</li>
                                    <li>Lead Nurturing</li>
                                    <li>Monthly Reports</li>
                                    <li>Market Research</li>
                                    <li class="pricing">Price</li>
                                </ul>
                            </div>
                            <div class="col-second-packages">
                                <div class="row-services-packages">
                                    <div class="packages-all packages-basic active-pricing">
                                        <h3>Basic</h3>
                                        <ul>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li>Text & Image</li>
                                            <li>FB/Insta</li>
                                            <li>Pixel</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>25</li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li class="pricing-packages">
                                                <p class="same-font-sizing">$1,500</p>
                                            </li>
                                        </ul>
                                        <div class="packages-btn">
                                            <button class="btn-regular orange-btn btn-weight-medium" data-bs-toggle="modal" data-bs-target="#getstarted">
                                                <span> Get Started </span>
                                                <span class="icon-arrow-image">
                                                    <i class="fa-solid fa-arrow-right"></i>
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="packages-all packages-pro">
                                        <h3>Pro</h3>
                                        <ul>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li>Text, Image</li>
                                            <li>FB/Insta/Google</li>
                                            <li>Pixel & Google Analytics</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>50</li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li class="pricing-packages">
                                                <p class="same-font-sizing">$2,500</p>
                                            </li>
                                        </ul>
                                        <div class="packages-btn">
                                            <button class="btn-regular orange-btn btn-weight-medium" data-bs-toggle="modal" data-bs-target="#getstarted">
                                                <span> Get Started </span>
                                                <span class="icon-arrow-image">
                                                    <i class="fa-solid fa-arrow-right"></i>
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="packages-all packages-custom">
                                        <h3>Custom</h3>
                                        <ul>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>Text, Image & Video</li>
                                            <li>FB/Insta/Google/YouTube</li>
                                            <li>Pixel, Analytics, Click Funnel</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>-</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li class="pricing-packages quote-price">
                                                <button class="btn-regular orange-btn btn-weight-medium btn-weight-medium-blue" data-bs-toggle="modal" data-bs-target="#getstarted">
                                                    <span>Get A Quote</span>
                                                    <span class="icon-arrow-image">
                                                        <i class="fa-solid fa-arrow-right"></i>
                                                    </span>
                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/leadgeneration.blade.php ENDPATH**/ ?>