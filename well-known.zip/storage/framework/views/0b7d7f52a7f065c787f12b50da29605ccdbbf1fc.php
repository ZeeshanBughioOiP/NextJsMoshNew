

<?php $__env->startSection('title','Contact'); ?>
<?php $__env->startSection('metadescription',''); ?>
<?php $__env->startSection('keywords', ''); ?>
<?php $__env->startSection('content'); ?>


        <section class="banner-contact">
            <div class="container-1470">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="contact-banner-heading">
                            <h1 class="contact-before-heading">Contact us</h1>
                            <p>Learn how we can assist you in achieving your goals, get in touch with us right away and let's begin collaborating on your success!</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="image-contact">
                            <img class="w-100" src="<?php echo e(asset('assets/image/contact/bg-image-contact.png')); ?>" alt="">
                            <div class="image-on-top">
                                <img class="w-100" src="<?php echo e(asset('assets/image/contact/contact-img.png')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="contact-main-information">
            <div class="container-1470">
                <div class="text-contact text-center">
                    <h4 class="fa-50 text-capitalize">not sure where to start?</h4>
                    <p class="fa-22">Chat with us, schedule a call or fill out our form below</p>
                </div>
                <div class="row-contact">
                    <div class="col-form-contact">
                        <div class="form-main-portion">
                            <h3>Send us a Message</h3>
                            <h6>Contact Us</h6>
                            <form class="modal-form form1">
                                <input type="hidden" name="page-name" class="page-name" value="contact">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="input-form-contact">
                                            <input type="text" id= 'fname' name= 'fname' placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="input-form-contact">
                                            <input type="text" id= 'lname' name= 'lname' placeholder="Last Name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="input-form-contact">
                                            <input type="email" id= 'email' name= 'email' placeholder="Email" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="input-form-contact">
                                            <input type="number" id= 'number' name= 'phone' placeholder="Phone" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="input-form-contact">
                                            <input type="text" id= 'company' name= 'company' placeholder="Company" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="input-form-contact">
                                            <input type="text" id= 'website_url' name= 'website_url' placeholder="Company Website URL" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="services-of-interest">
                                    <h6>Services Of Interest:</h6>
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                            <div class="input-radio-form">
                                                <input type="radio" class="serviceofinterest" name="serviceofinterest" id="lead">
                                                <label for="lead">Leads</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                            <div class="input-radio-form">
                                                <input type="radio" class="serviceofinterest" name="serviceofinterest" id="engagement">
                                                <label for="engagement">Engagement</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                            <div class="input-radio-form">
                                                <input type="radio" class="serviceofinterest" name="serviceofinterest" id="sales">
                                                <label for="sales">sales</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                            <div class="input-radio-form">
                                                <input type="radio" class="serviceofinterest" name="serviceofinterest" id="appointments">
                                                <label for="appointments">Appointments</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                            <div class="input-radio-form">
                                                <input type="radio" class="serviceofinterest" name="serviceofinterest" id="traffic">
                                                <label for="traffic">traffic</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                            <div class="input-radio-form">
                                                <input type="radio" class="serviceofinterest" name="serviceofinterest" id="appdownloads">
                                                <label for="appdownloads">App Downloads</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-area">
                                    <h6>Let us know about your project</h6>
                                    <div class="input-form-contact">
                                        <textarea placeholder="Type Your Message" id="message" name="message" required></textarea>
                                    </div>
                                </div>
                                <button class="btn-regular orange-btn btn-weight-medium" type="submit">
                                    <span>Submit</span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </button>
                            </form>
                        </div>
                    </div>
                    <div class="col-form-contact-information">
                        <h4 class="fa-50">Our Headquaters</h4>
                        <div class="address-portions">
                            <h6>Texas</h6>
                            <p>9115 FM 723 RD STE 550 RICHMOND,<br>TX 77406-9238, USA</p>
                        </div>
                        <div class="address-portions">
                            <h6>Dubai</h6>
                            <p>36 D2, Ajman Free Zone, Ajman UAE</p>
                        </div>
                        <div class="address-portions">
                            <h6>Karachi</h6>
                            <p>Suite 102, Haryani Square, Phase-VI, <br>DHA, KHI.</p>
                        </div>
                        <div class="address-portions">
                            <h6>Guangzhou</h6>
                            <p>Room 3311, East Tower, No 122 Tiyudong Rd, <br>Tianhe District, Guangzhou</p>
                        </div>
                        <div class="address-portions">
                            <h6>Phone</h6>
                            <a class="font-weight-bold" href="tel:+16092815203">+1 (609) 281 5203</a>
                        </div>
                        <div class="address-portions">
                            <h6>Email</h6>
                            <a href="mailto:info@croxpertz.com">info@croxpertz.com</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="we-can-help">
            <div class="container-1470">
                <h4 class="fa-50 text-center">Other Ways we can help</h4>
                <div class="we-can-help-main">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="items-experience">
                                <h4 class="bg-gradient-blue position-static transform-none mx-auto">General Inquiries</h4>
                                <p>Please don't hesitate to get in touch with us if you need  help or have any other queries.</p>
                                <button class="btn-regular orange-btn btn-weight-medium" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="items-experience">
                                <h4 class="bg-gradient-orange position-static transform-none mx-auto">Technical Support</h4>
                                <p>You can trust that we are here to help because our technical support team is on call around-the-clock.</p>
                                <button class="btn-regular btn-weight-medium-blue btn-weight-medium" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </button>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="items-experience">
                                <h4 class="bg-gradient-blue position-static transform-none mx-auto">Start Service</h4>
                                <p>We offer expert assistance for startup and increasing conversions. Contact us for more information.</p>
                                <button class="btn-regular orange-btn btn-weight-medium" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="certification-sec">
            <div class="container-1470">
                <h6>Certifications</h6>
                <div class="certification-images">
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification1.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification2.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification3.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification4.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification5.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/contact.blade.php ENDPATH**/ ?>