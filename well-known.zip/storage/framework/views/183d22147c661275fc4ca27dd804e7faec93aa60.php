

<?php $__env->startSection('title','About'); ?>
<?php $__env->startSection('metadescription',''); ?>
<?php $__env->startSection('keywords', ''); ?>
<?php $__env->startSection('content'); ?>

<section class="banner-section-about background-after-image-blurred">
            <h4>About</h4>
            <div class="heading-croxpertz">
                <img src="<?php echo e(asset('assets/image/about/heading-croxpertz.png')); ?>" alt="">
            </div>
            <div class="container-1518">
                <p>The objective of cro consulting is to optimize our client’s business for their higher conversion and more revenues. We provide data-driven and result-oriented Conversion Rate Optimisation services for businesses through continuous innovation, expert analysis, and personalized strategies. Our team employs cutting-edge techniques and the most recent industry insights to provide custom CRO solutions that increase conversion rates and drive meaningful growth. With our tried-and-tested conversion rate strategies, you can ramp up your ROI.</p>
            </div>
        </section>

        <section class="why-us arrow-back-section-before">
            <div class="container-1222">
                <h3>Why Us?</h3>
                <div class="row image-arrow-after">
                    <div class="col-md-6">
                        <div class="item-blurb">
                            <div class="item-blurb-header">
                                <h4>We put <br>clients first</h4>
                                <div class="image-blurb-item">
                                    <img src="<?php echo e(asset('assets/image/about/clientfirst.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src="<?php echo e(asset('assets/image/about/clientfirst.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>It's essential to establish an open line of communication with our clients so they can easily express their needs and expectations. We aim to develop unique solutions for their business and support them in achieving their goals.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="item-blurb">
                            <div class="item-blurb-header">
                                <h4>We care <br>for results</h4>
                                <div class="image-blurb-item">
                                    <img src="<?php echo e(asset('assets/image/about/wecareforresults.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src="<?php echo e(asset('assets/image/about/wecareforresults.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Our CRO Xpertz team knows that our customers demand more from us than just sincere intentions and assurances. Therefore, we concentrate heavily on getting results and generating more profit for our clients.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="item-blurb item-blurb-full">
                            <div class="item-blurb-header">
                                <h4>We are committed to diversity,<br> equity and inclusion</h4>
                                <p>We personally believe that diversity and inclusion in the workplace promote creativity, innovation, and better financial results. We are dedicated to creating a secure and welcoming atmosphere for all of our workers, clients, and partners because we appreciate and embrace diversity in all of its forms that bring a broad spectrum of viewpoints and experiences together.</p>
                            </div>
                            <div class="image-blurb-item">
                                <img src="<?php echo e(asset('assets/image/about/diversity.png')); ?>" alt="">
                                <img class="abs-image-blur-abs" src="<?php echo e(asset('assets/image/about/diversity.png')); ?>" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="item-blurb">
                            <div class="item-blurb-header">
                                <h4>We lead with <br>compassion</h4>
                                <div class="image-blurb-item">
                                    <img src="<?php echo e(asset('assets/image/about/compassion.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src="<?php echo e(asset('assets/image/about/compassion.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Compassionately-led businesses are not just more successful but also have a bigger influence on society in general. We are dedicated to changing the world through our compassionate approach to business because we believe that business is about more than just making money.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="item-blurb">
                            <div class="item-blurb-header">
                                <h4>We thoughtfully <br>challenge</h4>
                                <div class="image-blurb-item">
                                    <img src="<?php echo e(asset('assets/image/about/challenge.png')); ?>" alt="">
                                    <img class="abs-image-blur-abs" src="<?php echo e(asset('assets/image/about/challenge.png')); ?>" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Businesses with a greater willingness to take on risks and change with the times have the potential to grow significantly. For this reason, we eagerly welcome challenges and look for ways to learn from them.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="certification-sec">
            <div class="container-1470">
                <h6>Certifications</h6>
                <div class="certification-images">
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification1.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification2.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification3.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification4.png')); ?>" alt="">
                    </div>
                    <div class="certificatesimg">
                        <img src="<?php echo e(asset('assets/image/about/certification5.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </section>

        <section class="amplify-section">
            <div class="container-1470">
                <div class="row">
                    <div class="col-md-6">
                        <div class="amplify-item orange-bg">
                            <h6>Let's <br>Talk<br>  Results!</h6>
                            <a class="btn-regular" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                <span> Get Started </span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="amplify-item blue-bg">
                            <h6>Let's <br>Talk<br>  Numbers!</h6>
                            <a class="btn-regular orange-btn" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                <span> Get Started </span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/about.blade.php ENDPATH**/ ?>