
<?php $__env->startSection('title','Ztech Design'); ?>
<?php $__env->startSection('metadescription',''); ?>
<?php $__env->startSection('keywords', ''); ?>
<?php $__env->startSection('content'); ?>


        <section class="banner-section-case-studies">
            <div class="container-1470">
                <div class="text-case-studies">
                    <h5 class="bg-gradient-orange">Case Study</h5>
                    <div class="image-banner-case-study-single">
                        <h3>Ztech Design</h3>
                        <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/ztechdesign/banner.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </section>

        <section class="case-studies-single-about">
            <div class="container-1470">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="text-case-study-single">
                            <h4>What exactly is <br>Ztech Design</h4>
                            <p>Ztech is a digital agency that specializes in providing a range of services such as Social Media Marketing, Web Development, SEO, Google Ads, and Creative Designing. Ztech is focused on helping businesses establish their digital presence, improve their online visibility, and achieve their goals through innovative and effective digital solutions.</p>
                            <p>With our comprehensive strategies and experienced professionals, Ztech now delivers top-quality services to clients across various industries.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="image-about-single">
                            <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/ztechdesign/about.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="case-studies-challenge">
            <div class="container-1470">
                <div class="case-challenge-row">
                    <div class="image-challenge">
                        <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/ztechdesign/challenge.png')); ?>" alt="">
                    </div>
                    <div class="text-challenge">
                        <div class="portion-challenge bg-blue-gradient-challenge text-white">
                            <h3 class="before-number fa-50">The Challenge</h3>
                            <p>The agency has been in business for months and has struggled to attract new clients and retain existing ones. They approached us to help them improve their marketing efforts and focus on delivering delightful user experiences that would help them retain clients.</p>
                            <p>Ztech had a limited online presence and struggled to attract new clients. The agency had no consistent lead generation strategy in place, which resulted in a sporadic flow of new clients. They struggled to retain clients due to a lack of focus on delivering delightful user experiences and meeting their clients' needs. To attract and retain clients, we must focus on delivering high-quality services that meet or exceed their expectations.</p>
                        </div>
                        <div class="portion-challenge">
                            <h3 class="before-number number-2 fa-50">The Client</h3>
                            <p>Clients expect that we will deliver results that align with their business objectives. They expect that the strategies and campaigns we develop will help them achieve their goals, such as building a social presence on different social platforms, and increasing website traffic, leads, conversions, and revenue.</p>
                            <p>By meeting these expectations, we can build trust with our clients, establish ourselves as a trusted and reliable digital agency, and foster long-term relationships that are beneficial to both parties.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="case-study-wwd">
            <div class="container-1470">
                <div class="text-wwd">
                    <h3 class="before-number number-3 fa-50">What we did.</h3>
                    <p>As per the client's expectations, we implemented a comprehensive digital marketing strategy for Ztech that focused on building their social presence and generating sales. </p>
                    <p>Through these strategies, Ztech's social media profiles saw a significant increase in followers and engagement, and their website traffic increased by over 50%. Ztech's PPC campaigns generated a significant number of leads and sales, and their content marketing efforts positioned them as a thought leader in the industry. Overall, these strategies helped make Ztech a successful digital agency in the market.</p>
                </div>
                <div class="wwd-img">
                    <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/ztechdesign/whatwedid.png')); ?>" alt="">
                </div>
            </div>
        </section>

        <section class="case-study-single-services">
            <div class="container-1470">
                <div class="case-study-single-services-text">
                    <h4 class="fa-50">Our extreme focus on <br>delightful user experience</h4>
                    <p class="fa-18">Ztech Digital's website traffic increased by over 75% within six months of implementing our digital marketing strategy. Their brand awareness increased significantly, with their online presence and social media following growing substantially, lead generation efforts became more consistent, with a steady flow of new leads and inquiries coming in each month.</p>
                </div>
            </div>
            <div class="service-case-study">
                <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/ztechdesign/services.png')); ?>" alt="">
            </div>
        </section>

        <section class="sec-conclusion">
            <div class="container-1470">
                <h4 class="fa-50 mb-20">Conclusion</h4>
                <div class="conclusion-portion">
                    <p class="fa-18">Ztech's focus is on providing services in Social Media Marketing, Web Development, SEO, PPC, and Creative Designing. By delivering quality work and ensuring client satisfaction, they were able to build their presence in the digital business and grow their client base. In conclusion, Ztech's success is a testament to the importance of prioritizing user experiences and delivering quality services in the digital world.</p>
                    <img src=" <?php echo e(asset('assets/image/casestudies/quoteimage.png')); ?>" alt="">
                </div>
            </div>
        </section>

        <section class="amplify-section">
            <div class="container-1470">
                <h3 class="fa-50 text-center mb-5">Similar Case Studies</h3>
                <div class="row">
                    <div class="col-md-6">
                        <div class="amplify-item orange-bg">
                            <h6>Atlas Design</h6>
                            <a class="btn-regular" href="<?php echo e(URL::to('/atlas')); ?>">
                                <span>Have a look</span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="amplify-item blue-bg">
                            <h6>Vital Rental</h6>
                            <a class="btn-regular orange-btn" href="<?php echo e(URL::to('/vitalrental')); ?>">
                                <span> Have a look </span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/ztechdesign.blade.php ENDPATH**/ ?>