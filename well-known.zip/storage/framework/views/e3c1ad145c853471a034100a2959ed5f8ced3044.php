

<?php $__env->startSection('title','Blogs'); ?>
<?php $__env->startSection('metadescription','Blogs'); ?>
<?php $__env->startSection('keywords','Blogs'); ?>
<?php $__env->startSection('static_url','https://www.croxpertz.com/blogs'); ?>
<?php $__env->startSection('class-body','no-overflow-for-sticky'); ?>

<?php $__env->startSection('content'); ?>

    <section class="banner-section-services background-after-image-blurred banner-privacy">
            <div class="before-image-banner position-relative">
                <a href="#sec2" class="secdown">
                    <p>Scroll to explore</p>
                    <span><img src="<?php echo e(asset('assets/image/ArrowULeftDown.png')); ?>" alt=""></span>
                </a>
                <div class="container-1470 position-relative">
                    <div class="banner-flex">
                        <div class="image-banner-left image-banner">
                            <img src=" <?php echo e(asset('assets/image/services/leadgeneration/banner-bottom.png')); ?>" alt="">
                        </div>
                        <div class="banner-content-services">
                            <div>
                                <h1>Blogs</h1>
                                <p></p>
                                <a class="btn-regular orange-btn btn-weight-medium" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                                <?php echo $__env->make('socialicons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="image-banner-right image-banner">
                            <img src=" <?php echo e(asset('assets/image/services/leadgeneration/banner-top.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <section class="position-relative our-blogs" id="our-blogs-m" >
        <div class="container-1470" id="next">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                
                    <?php 
                        if(!empty($data) && $data->count()) {
                            foreach($data as $d){ ?>
                            <div class="col-lg-6 col-md-6 mbblogs-50">
                                <div class="blogs-box-designed">
                                    <a href="<?php echo e(url('/'.$d->slug_name)); ?>">
                                    <img src="<?=url('uploads/apifileregistration/'.$d->post_image); ?>">
                                        <div>
                                            <h2><?=$d->post_name; ?></h2>
                                            <p>Posted on: <?php echo e($d->created_at->format('j-F-Y')); ?></p>
                                            <!--<p><?=$d->post_short_description; ?></p>-->
                                            <!--<span>Read More</span>-->
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php
                        } 
                    } else { ?>
                        <div class="col-md-12 mbblogs-50">
                            <div class="blogs-box-designed">
                                <a href="#!">
                                    <div>
                                        <h2 class="mb-0">There are no data.</h2>
                                    </div>
                                </a>
                            </div>
                        </div>
                   <?php  } ?>
                    <div class="col-lg-12">
                        <?php echo $data->links(); ?>

                    </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="follow-us-blogs">
                            <div class="social-links flex-column align-items-start">
                                <h5>Follow Us</h5>
                                <div class="social-links-wrap">
                                    <a href="https://www.facebook.com/profile.php?id=100091206667713" class="social-link fb-link"><i class="fa-brands fa-facebook-f"></i></a>
                                    <a href="https://www.instagram.com/croxpertz/" class="social-link insta-link"><i class="fa-brands fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    <div class="sticky-recent-posts">
                        <div class="box-blogs-recent">
                            <div class="row">
                            <div class="col-lg-12">
                                <h3>Recent Posts</h3>
                            </div>
                            <div class="col-lg-12">
                                <div class="row">
                
                                <?php 
                                    if(!empty($data) && $data->count(3)) {
                                        foreach($data as $key => $d){ ?>
                                        <?php if($key <= 6): ?>
                                        <div class="col-lg-12 mbblogs-50">
                                            <div class="blogs-box">
                                                <a href="<?php echo e(url('/'.$d->slug_name)); ?>">
                                                <!--<img src="<?=url('uploads/apifileregistration/'.$d->post_image); ?>">-->
                                                    <div>
                                                        <h2><?=$d->post_name; ?></h2>
                                                        <p>Posted on: <?php echo e($d->created_at->format('j-F-Y')); ?></p>
                                                        <!--<p><?=$d->post_short_description; ?></p>-->
                                                        <!--<span>Read More</span>-->
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    <?php
                                    } 
                                } else { ?>
                                    <div class="col-lg-12">
                                        <div class="blogs-box">
                                            <a href="#!">
                                                <div>
                                                    <h2>There are no data.</h2>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                               <?php  } ?>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
  <script>
    $(document).ready(function(){
        $('html, body').animate({
            scrollTop: $(".blogs section#our-blogs-m").offset().top
        }, 500);
        $("p:empty").addClass("empty-paragraph");
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/blogs.blade.php ENDPATH**/ ?>