<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<url>
<loc><?php echo e(url('/')); ?>/</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>1.00</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/about</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/lead-generation</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/traffic-conversion-optimization</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/ecommerce-optimization-services</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/brand-engagement-agency</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/appointment-scheduling-solution</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/app-marketing-agency</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/blogs</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/casestudies</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/contact</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/atlas</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.8</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/vitalrental</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.8</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/ztechdesign</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.8</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/termsandconditions</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.60</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/privacypolicy</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.60</priority>
</url>
<url>
<loc><?php echo e(url('/')); ?>/refundpolicy</loc>
<lastmod>2023-08-02T18:53:50+00:00</lastmod>
<priority>0.60</priority>
</url>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <url>
        <loc><?php echo e(url('/')); ?>/<?php echo e($post->slug_name); ?></loc>
        <lastmod><?php echo e($post->created_at->tz('UTC')->toAtomString()); ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>0.8</priority>
    </url>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset><?php /**PATH /home2/croxpertz/public_html/resources/views/sitemap.blade.php ENDPATH**/ ?>