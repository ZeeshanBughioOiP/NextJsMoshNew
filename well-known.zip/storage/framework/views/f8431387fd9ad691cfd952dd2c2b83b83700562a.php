
<?php $__env->startSection('title','Vital Rental'); ?>
<?php $__env->startSection('metadescription',''); ?>
<?php $__env->startSection('keywords', ''); ?>
<?php $__env->startSection('content'); ?>


        <section class="banner-section-case-studies vital-renting">
            <div class="container-1470">
                <div class="text-case-studies">
                    <h5 class="bg-gradient-orange">Case Study</h5>
                    <h3>Vital Rental</h3>
                    <div class="image-banner-case-study-single-rental">
                        <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/vitalrenting/banner.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </section>

        <section class="case-studies-single-about">
            <div class="container-1470">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="text-case-study-single">
                            <h4>What exactly is <br>Vital Renting</h4>
                            <p>Vital Rental is a popular car rental service in Australia that operates 24/7, providing customers with flexible and convenient options. They offer an extensive range of vehicles, including cars, and SUVs. Their affordable pricing and customer-friendly policies make them a top choice for rentals.</p>
                            <p>The company has been in business for several years. And now they have established a reputation for delivering steady and convenient rental services.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="image-about-single">
                            <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/vitalrenting/about.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="case-studies-challenge pb-100">
            <div class="container-1470">
                <div class="case-challenge-row">
                    <div class="image-challenge">
                        <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/vitalrenting/challenge.png')); ?>" alt="">
                    </div>
                    <div class="text-challenge">
                        <div class="portion-challenge bg-blue-gradient-challenge text-white">
                            <h3 class="before-number fa-50">The Challenge</h3>
                            <p>We faced a challenge to build their online presence, as they lacked in terms of advancement like; user-experience, accessibility, ranking, easy checkout process. It posed a significant obstacle.</p>
                            <p>Recognizing the competitive nature of the market, we understood the significance of enhancing Vital Rental's online visibility to attract and retain customers. Our strategy aimed to improve their brand awareness and create a strong online reputation to differentiate them from their competitors.</p>
                        </div>
                        <div class="portion-challenge">
                            <h3 class="before-number number-2 fa-50">The Client</h3>
                            <p>To meet our client's expectations and align their business objectives, we tailored digital solutions that catered to the specific needs of a car rental business. Our approach focused on increasing website traffic, enhancing customer engagement, and boosting sales to improve Vital Rental's online presence.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="case-study-wwd">
            <div class="container-1470">
                <div class="text-wwd">
                    <h3 class="before-number number-3 fa-50">What we did.</h3>
                    <p>Our first step was to revamp Vital Rental's website, improving its appearance, usability, and functionality. Additionally, we launched targeted ad campaigns and social media advertising initiatives to increase their online presence. To further enhance their visibility, we also optimized the website and online content for search engines, aiming to improve their rankings on search engine results pages.</p>
                </div>
                <div class="wwd-img">
                    <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/vitalrenting/whatwedid.png')); ?>" alt="">
                </div>
            </div>
        </section>

        <section class="case-study-single-vital-renting">
            <div class="container-1470">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <h4 class="fa-50">Our extreme focus on <br> delightful user experience</h4>
                    </div>
                    <div class="col-lg-6">
                        <p class="mx-646 fa-18 ml-auto">We recognized the importance of a seamless user experience in achieving our digital strategy's success. Therefore, we designed and developed a visually appealing website and digital presence that prioritized ease of use, providing customers with a delightful experience across all devices.</p>
                    </div>
                </div>
            </div>
            <div class="container-1253">
                <div class="service-item-vital">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-5">
                            <div class="image-vital-service">
                                <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/vitalrenting/schedule.png')); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-7">
                            <div class="text-vital-service mx-646 ml-auto">
                                <h4 class="fa-50">Schedule & Select Services</h4>
                                <p class="fa-18">We created a user-friendly environment that integrated a feature enabling customers to quickly and easily view available rental vehicles. We streamlined the rental process, allowing customers to select the required dates and times and provide their details by filling forms.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="service-item-vital">
                    <div class="row align-items-center">
                        <div class="col-lg-7 col-md-7">
                            <div class="text-vital-service mx-646 mr-auto">
                                <h4 class="fa-50">Business Development</h4>
                                <p class="fa-18">Our digital solutions not only improved Vital Rental's online presence but also assisted their operational department in delivering better services. By managing reservations more efficiently and promptly, we helped Vital Rental enhance their customer experience and generate more bookings and revenue.</p>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-5">
                            <div class="image-vital-service ml-auto">
                                <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/vitalrenting/business.png')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="service-item-vital">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-5">
                            <div class="image-vital-service">
                                <img class="w-100" src=" <?php echo e(asset('assets/image/casestudies/vitalrenting/realtime.png')); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-7">
                            <div class="text-vital-service mx-646 ml-auto">
                                <h4 class="fa-50">Realtime Assistance</h4>
                                <p class="fa-18">Vital Rental understands the importance of customer satisfaction in driving business success. By introducing an instant chat box function on their website, they can provide real-time assistance to customers, improving the overall rental experience. This customer-centric approach has helped Vital Rental establish a strong reputation in the competitive Australian car rental market.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="sec-conclusion">
            <div class="container-1470">
                <h4 class="fa-50 mb-20">Conclusion</h4>
                <div class="conclusion-portion">
                    <p class="fa-18">We've had a two-year relationship with Vital Rental, and the results speak for themselves. Our collaboration demonstrates the significance of individualized digital solutions, and we look forward to continuing our collaboration with them in years to come.</p>
                    <img src=" <?php echo e(asset('assets/image/casestudies/quoteimage.png')); ?>" alt="">
                </div>
            </div>
        </section>

        <section class="amplify-section">
            <div class="container-1470">
                <h3 class="fa-50 text-center mb-5">Similar Case Studies</h3>
                <div class="row">
                    <div class="col-md-6">
                        <div class="amplify-item orange-bg">
                            <h6>Ztech Design</h6>
                            <a class="btn-regular" href="<?php echo e(URL::to('/ztechdesign')); ?>">
                                <span>Have a look</span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="amplify-item blue-bg">
                            <h6>Atlas Rental</h6>
                            <a class="btn-regular orange-btn" href="<?php echo e(URL::to('/atlas')); ?>">
                                <span> Have a look </span>
                                <span class="icon-arrow-image">
                                    <i class="fa-solid fa-arrow-right"></i>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/croxpertz/public_html/resources/views/vitalrental.blade.php ENDPATH**/ ?>