<?php

use App\Http\Controllers\Links\Links;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\Blogadmin\Admin\Post;
use App\Http\Controllers\Blogadmin\Admin\Profile;
use App\Http\Controllers\Blogadmin\AuthController;

View::composer('*', function ($view) {
    $view_without_replacement = str_replace('.', '/', $view->getName());
    $view_name = str_replace('.', '-', $view->getName());
    View::share('view_name', $view_name);
    View::share('view_without_replacement', $view_without_replacement);
});


// Sitemap

Route::get("sitemap.xml" , function () {
    return \Illuminate\Support\Facades\Redirect::to('sitemap.xml');
});

// Sitemap


Route::post('/ajaxForm', [Links::class, 'form']);

Route::view('/','home')->name('home');
Route::view('/about','about')->name('about');
Route::view('/contact','contact')->name('contact');

// Services

Route::view('/lead-generation','leadgeneration')->name('leadgeneration');
Route::view('/traffic-conversion-optimization','trafficoptimization')->name('trafficoptimization');
Route::view('/ecommerce-optimization-services','ecommerceoptimization')->name('ecommerceoptimization');
Route::view('/brand-engagement-agency','brandengagement')->name('brandengagement');
Route::view('/appointment-scheduling-solution','appointmentscheduling')->name('appointmentscheduling');
Route::view('/app-marketing-agency','appdownloads')->name('appdownloads');


// Case Studies

Route::view('/casestudies','casestudies')->name('casestudies');
Route::view('/atlas','atlas')->name('atlas');
Route::view('/ztechdesign','ztechdesign')->name('ztechdesign');
Route::view('/vitalrental','vitalrental')->name('vitalrental');


// Privacy & Policy
Route::view('/privacypolicy','privacypolicy')->name('privacypolicy');
Route::view('/termsandconditions','termsandconditions')->name('termsandconditions');
Route::view('/refundpolicy','refundpolicy')->name('refundpolicy');



Route::view('/thankyou','thankyou')->name('thankyou');


//hannan work


// Blogs
Route::any('/blogs', [Links::class, 'blogs']);
Route::any('/blogs/blog1', [Links::class, 'blog1']);
Route::any('/blogs/blog2', [Links::class, 'blog2']);
Route::any('/blogs/blog3', [Links::class, 'blog3']);
//Blog Dashboard


Route::get('/blogadmin', [AuthController::class, 'index'])->name('login');
Route::post('post-login', [AuthController::class, 'postLogin'])->name('login.post'); 
Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::get('logout', [AuthController::class, 'logout'])->name('logout');
Route::post('post-registration', [AuthController::class, 'postRegistration'])->name('register.post'); 
Route::get('addpost', [Post::class, 'index'])->name('addpost'); 
Route::post('/savepost', [Post::class, 'savepost'])->name('savepost'); 
Route::get('postlist', [Post::class, 'postlist'])->name('postlist'); 
Route::get('post_delete/{id}', [Post::class,'post_delete']);
Route::get('post_edit/{id}', [Post::class,'post_edit']);
Route::post('postupdate', [Post::class, 'postupdate'])->name('postupdate'); 
Route::get('edit_profile/{id}', [Profile::class,'edit_profile']);
Route::post('profileupdate', [Profile::class, 'profileupdate'])->name('profileupdate'); 
Route::get('allpostlist', [Post::class, 'allpostlist'])->name('allpostlist'); 
Route::get('disapproved/{id}', [Post::class,'disapproved']);
Route::get('approved/{id}', [Post::class,'approved']);
Route::get('allblogs', [Blogs::class, 'allblogs'])->name('allblogs'); 
Route::get('dislike/{id}', [Blogs::class,'dislike']);
Route::get('like/{id}', [Blogs::class,'like']);
Route::post('blogform', [Blogs::class, 'blogform'])->name('blogform'); 
Route::post('addcomment', [Blogs::class, 'addcomment'])->name('addcomment'); 
Route::get('alllike', [Blogs::class, 'alllike'])->name('alllike'); 
Route::get('mybloglikes', [Blogs::class, 'mybloglikes'])->name('mybloglikes'); 
Route::get('allcomments', [Blogs::class, 'allcomments'])->name('allcomments'); 
Route::get('mycomments', [Blogs::class, 'mycomments'])->name('mycomments');
Route::get('showcomments/{id}', [Blogs::class,'showcomments']);

// SiteMap URL
Route::get('sitemap.xml', [SitemapController::class, 'index']);
Route::get('sitemap', [SitemapController::class, 'index']);

// Do not add route below this blogdetail route
Route::get('/{id}', [Links::class,'blogdetail'])->name('blogDetails');

//hannan work
