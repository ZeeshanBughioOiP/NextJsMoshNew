<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
    $currentURL = Request::url();
    ?>

    <title property="title">@yield('title') - CROXpertz</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta property="description" name="description" content="@yield('metadescription')">
    <meta name="keywords" content="@yield('keywords')">

    <?php if($currentURL == 'https://croxpertz.com/privacypolicy' || $currentURL == 'https://croxpertz.com/termsandconditions' || $currentURL == 'https://croxpertz.com/refundpolicy' || $currentURL == 'https://croxpertz.com/thankyou'){  ?>
    <meta name="robots" content="noindex, nofollow">
    <?php  } else { ?>
    <meta name="robots" content="index, follow">
    <?php } ?>
    <link rel="icon" href="assets/image/FavIcon.png" type="image/x-icon">
    <meta property="og:site_name" content="CROXpertz">
    <meta property="og:title" content="CROXpertz">
    <meta property="og:description" content="">
    <meta property="og:image" content="{{ asset('assets/image/og-image.png') }}">
    <meta name="google-site-verification" content="Xx3yzcdMdVrJrAf_LxjTNP343QRTnVUyfVZ7szGekAA" />
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css">

    <link rel="stylesheet" href="{{ asset('assets/style/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/style/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/style/responsive.css') }}">

    <!-- Meta Pixel Code -->
    <!--<script>-->
    <!--    ! function(f, b, e, v, n, t, s) {-->
    <!--        if (f.fbq) return;-->
    <!--        n = f.fbq = function() {-->
    <!--            n.callMethod ?-->
    <!--                n.callMethod.apply(n, arguments) : n.queue.push(arguments)-->
    <!--        };-->
    <!--        if (!f._fbq) f._fbq = n;-->
    <!--        n.push = n;-->
    <!--        n.loaded = !0;-->
    <!--        n.version = '2.0';-->
    <!--        n.queue = [];-->
    <!--        t = b.createElement(e);-->
    <!--        t.async = !0;-->
    <!--        t.src = v;-->
    <!--        s = b.getElementsByTagName(e)[0];-->
    <!--        s.parentNode.insertBefore(t, s)-->
    <!--    }(window, document, 'script',-->
    <!--        'https://connect.facebook.net/en_US/fbevents.js');-->
    <!--    fbq('init', '191886536580711');-->
    <!--    fbq('track', 'PageView');-->
    <!--</script>-->
    <!--<noscript><img height="1" width="1" style="display:none"-->
    <!--        src="https://www.facebook.com/tr?id=191886536580711&ev=PageView&noscript=1" /></noscript>-->
    <!-- End Meta Pixel Code -->
    <!-- Meta Pixel Code -->
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '964372911461249');
      fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=964372911461249&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Meta Pixel Code -->
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-KN2TZN6');
    </script>
    <!-- End Google Tag Manager -->

</head>

<body class="@yield('class-body')">
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KN2TZN6" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <main>

        <div class="loader-main">
            <div class="loaderImg"><img src="{{ asset('assets/image/2sec.gif') }}" /></div>
        </div>

        <header class="header-main">
            <div class="container-1470">
                <div class="row-head">
                    <div class="container-logo">
                        <a href="{{ URL::to('/') }}">
                            <img src="{{ asset('assets/image/logo.png') }}" alt="">
                        </a>
                    </div>
                    <div class="links">
                        <div class="icon-tablet-menu">
                            <span class="top-line line-menu"></span>
                            <span class="middle-line line-menu"></span>
                            <span class="bottom-line line-menu"></span>
                        </div>
                        <ul>
                            <li>
                                <a class=" {{ request()->is('/') ? 'active-menu' : '' }}"
                                    href="{{ URL::to('/') }}">Home</a>
                            </li>
                            <li>
                                <a class=" {{ request()->is('about') ? 'active-menu' : '' }}"
                                    href="{{ URL::to('/about') }}">About us</a>
                            </li>
                            <li class="sub-menu">
                                <a class=" " href="javascript:void(0)">Services <i
                                        class="fas fa-chevron-down fa-fw"></i></a>
                                <ul class="sub-menu-items">
                                    <h6 class="services-heading-submenu-top d-lg-none">Services</h6>
                                    <span class="back-icon fa fa-arrow-left d-lg-none"></span>
                                    <li>
                                        <a href="{{ URL::to('/lead-generation') }}">lead generation</a>
                                    </li>
                                    <li>
                                        <a href="{{ URL::to('/traffic-conversion-optimization') }}">traffic optimization</a>
                                    </li>
                                    <li>
                                        <a href="{{ URL::to('/ecommerce-optimization-services') }}">ecommerce optimization</a>
                                    </li>
                                    <li>
                                        <a href="{{ URL::to('/brand-engagement-agency') }}">brand engagement</a>
                                    </li>
                                    <li>
                                        <a href="{{ URL::to('/appointment-scheduling-solution') }}">appointment scheduling</a>
                                    </li>
                                    <li>
                                        <a href="{{ URL::to('/app-marketing-agency') }}">App Marketing Agency</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a class=" {{ request()->is('blogs') ? 'active-menu' : '' }}"
                                    href="{{ URL::to('/blogs') }}">Blogs</a>
                            </li>
                            <li>
                                <a class=" {{ request()->is('casestudies') ? 'active-menu' : '' }}"
                                    href="{{ URL::to('/casestudies') }}">Case Studies</a>
                            </li>
                            <li class="btn-parent-header">
                                <a class="btn-regular" href="{{ URL::to('/contact') }}">
                                    <span> Contact Us </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>



        @yield('content')


        @if (Route::current()->getName() == 'contact' ||
                Route::current()->getName() == 'casestudies' ||
                Route::current()->getName() == 'ztechdesign' ||
                Route::current()->getName() == 'vitalrental' ||
                Route::current()->getName() == 'atlas')
        @else
            <section class="sec-case-study">
                <div class="container-1470">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <h3>Case Studies</h3>
                        </div>
                        <div class="col-md-6">
                            <div class="text-wdth-case">
                                <p>We expect that reading through these case studies will help you better understand how
                                    we can support your company in overcoming similar obstacles.</p>
                            </div>
                        </div>
                    </div>
                    <div class="case-studies-items-main">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 mx-auto">
                                <div class="case-study-item text-center">
                                    <img class="w-100" src="{{ asset('assets/image/atlaslaptop.png') }}"
                                        alt="">
                                    <h5>Atlas <br> Digital</h5>
                                    <p>Atlas Digital is a full-service digital agency that specializes in providing a
                                        range of digital solutions to businesses of all sizes. Their team comprises
                                        experts in various fields, including digital marketing, creative designing, web
                                        development, video development, and app development.</p>
                                    <a href="{{ URL::to('/atlas') }}">
                                        <span>View Case Study</span>
                                        <span><i class="fa-solid fa-arrow-right"></i></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 mx-auto">
                                <div class="case-study-item item-hovered-on text-center">
                                    <img class="w-100" src=" {{ asset('assets/image/vitallaptop.png') }}"
                                        alt="">
                                    <h5>Vital <br> Rental</h5>
                                    <p>Vital Rental is a popular car rental service in Australia that operates 24/7,
                                        providing customers with flexible and convenient options. They offer an
                                        extensive range of vehicles, including cars, and SUVs. Their affordable pricing
                                        and customer-friendly policies make them a top choice for rentals.</p>
                                    <a href="{{ URL::to('/vitalrental') }}">
                                        <span>View Case Study</span>
                                        <span><i class="fa-solid fa-arrow-right"></i></span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 mx-auto">
                                <div class="case-study-item text-center">
                                    <img class="w-100" src=" {{ asset('assets/image/ztechlaptop.png') }}"
                                        alt="">
                                    <h5>Ztech <br> Design</h5>
                                    <p>Ztech is a digital agency that specializes in providing a range of services such
                                        as Social Media Marketing, Web Development, SEO, Google Ads, and Creative
                                        Designing. Ztech is focused on helping businesses establish their digital
                                        presence, improve their online visibility, and achieve their goals through
                                        innovative and effective digital solutions.</p>
                                    <a href="{{ URL::to('/ztechdesign') }}">
                                        <span>View Case Study</span>
                                        <span><i class="fa-solid fa-arrow-right"></i></span>
                                    </a>
                                </div>
                            </div>
                            <!--<div class="col-lg-3">-->
                            <!--    <div class="case-study-item">-->
                            <!--        <img class="w-100" src="assets/image/casestudies.png" alt="">-->
                            <!--        <h5>Lorem Ipsumm</h5>-->
                            <!--        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>-->
                            <!--        <a href="#">-->
                            <!--            <span>View Case Study</span>-->
                            <!--            <span><i class="fa-solid fa-arrow-right"></i></span>-->
                            <!--        </a>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
                </div>
            </section>
        @endif


        @if (Route::current()->getName() == 'contact')
        @else
            <section class="happy-clients">
                <div class="container-1470">
                    <h3>Happy Clients</h3>
                    <div class="happy-clients-box">
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/atlas.png') }}"
                                alt="">
                        </div>
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/motorific.png') }}"
                                alt="">
                        </div>
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/ztech.png') }}"
                                alt="">
                        </div>
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/vital.png') }}"
                                alt="">
                        </div>
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/immortal.png') }}"
                                alt="">
                        </div>
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/cmg.png') }}"
                                alt="">
                        </div>
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/brandignity.png') }}"
                                alt="">
                        </div>
                        <div class="hp-image">
                            <img class="w-100" src=" {{ asset('assets/image/happyclients/qme.png') }}"
                                alt="">
                        </div>
                    </div>
                </div>
            </section>
        @endif


        <section class="words-of-clients">
            <div class="container-1470">
                <h5>Words of our Clients</h5>
            </div>
            <div class="clients-testimonials">
                <div class="box-testimonial">
                    <div class="text-testimonial-box before-quote-sign">
                        <h3>Cynthia</h3>
                        <!--<span>Marketing Manager</span>-->
                        <div class="text-testimonial-main">
                            <p>I was able to produce excellent products, but I had no idea how to market them to
                                consumers.CRO Xpertz has helped me in increasing sales and they assisted me in expanding
                                the business. </p>
                        </div>
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <!--<i class="fa-regular fa-star"></i>-->
                        </div>
                    </div>
                </div>
                <div class="box-testimonial">
                    <div class="text-testimonial-box before-quote-sign">
                        <h3>Roy Solomon</h3>
                        <!--<span>Operation Manager</span>-->
                        <div class="text-testimonial-main">
                            <p>We hired CRO Xpertz to help our website's conversion rate, and I have to say they did
                                wonders, almost tripling our conversion rate with their CRO service; I will continue to
                                work with him. </p>
                        </div>
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="box-testimonial">
                    <div class="text-testimonial-box before-quote-sign">
                        <h3>Sebastine Sylvester</h3>
                        <!--<span>CEO</span>-->
                        <div class="text-testimonial-main">
                            <p>The CRO Xpertz team is highly skilled at designing efficient testing strategies that
                                greatly enhance conversion rates over time. They are also prompt and excellent project
                                managers. </p>
                        </div>
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="box-testimonial">
                    <div class="text-testimonial-box before-quote-sign">
                        <h3>Luke Edwin</h3>
                        <!--<span>Ecommerce Manager</span>-->
                        <div class="text-testimonial-main">
                            <p>They collaborate so carefully with us that we truly believe they are an extended version
                                of our team. I highly recommend it to anyone looking for professional work with a
                                high-quality dedicated CRO expert. </p>
                        </div>
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="subscribe-section">
            <div class="container-1518">
                <div class="subscription-main">
                    <h3>Get latest updates</h3>
                    <p>Sign up for our newsletter to receive the most recent digital news, trends, and extremely
                        valuable perspectives from our industry professionals.</p>
                    <form action="#" class="form1">
                        <div class="input-with-btn">
                            <input type="hidden" class="page-name" name="page-name" value="{{ $view_name }}">
                            <!--Division-->
                            <input type="hidden" class="price-package" name="price-package" value="">
                            <input type="hidden" class="package-name" name="package-name" value="">
                            <!--Service Name-->
                            <input type="hidden" id="name" name="name" value="subscribedField">
                            <input type="hidden" id="number" name="phone" value="">
                            <textarea id="message" name="message" hidden="hidden">Subscribed by Newsletter Form</textarea>
                            <input type="email" name="email" id="email" placeholder="Enter Your Email"
                                required>
                            <button type="submit">Subscribe</button>
                        </div>
                    </form>
                    <img src=" {{ asset('assets/image/subscribe-mob.png') }}" alt="">
                    <!--<img class="image-mob-subscription" src="assets/image/subscribe-mob.png" alt="">-->
                </div>
            </div>
        </section>

        <footer class="footer">
            <div class="footer-main">
                <div class="container-1470">
                    <div class="row-footer">
                        <div class="col-main col-first">
                            <div class="footer-logo">
                                <img src=" {{ asset('assets/image/logo-dark.png') }}" alt="">
                                <p>CRO is a recognized expert in the area of conversion rate optimization and an ideal
                                    partner for businesses looking to increase the usability of websites, engage
                                    visitors, and convert them into lifelong clients.</p>
                            </div>
                        </div>
                        <div class="col-main col-second">
                            <h4>Quick Links</h4>
                            <ul>
                                <li>
                                    <a href="{{ URL::to('/') }}">Home</a>
                                </li>
                                <li>
                                    <a href="{{ URL::to('/about') }}">About Us</a>
                                </li>
                                <li>
                                    <a href="{{ URL::to('/casestudies') }}">Case Studies</a>
                                </li>
                                <li>
                                    <a href="{{ URL::to('/contact') }}">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-main col-second">
                            <h4>Services</h4>
                            <ul>
                                <li>
                                    <a href="{{ URL::to('/lead-generation') }}">Lead Generation</a>
                                </li>
                                <li>
                                    <a href="{{ URL::to('/traffic-conversion-optimization') }}">Traffic Optimization</a>
                                </li>
                                <li>
                                    <a href=" {{ URL::to('/ecommerce-optimization-services') }}">Ecommerce Optimization</a>
                                </li>
                                <li>
                                    <a href=" {{ URL::to('/brand-engagement-agency') }}">Brand Engagement</a>
                                </li>
                                <li>
                                    <a href=" {{ URL::to('/appointment-scheduling-solution') }}">Appointment Scheduling</a>
                                </li>
                                <li>
                                    <a href=" {{ URL::to('/app-marketing-agency') }}">App Marketing Agency</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-main col-second col-last">
                            <div>
                                <h4>Legal</h4>
                                <ul>
                                    <li>
                                        <a href="{{ URL::to('/termsandconditions') }}">Terms & Condition</a>
                                    </li>
                                    <li>
                                        <a href="{{ URL::to('/privacypolicy') }}">Privacy Policy</a>
                                    </li>
                                    <li>
                                        <a href="{{ URL::to('/refundpolicy') }}">Refund Policy</a>
                                    </li>
                                </ul>
                            </div>
                            <div>
                                <h4>Contact Us</h4>
                                <ul class="contact-email-icons">
                                    <li>
                                        <a href="tel:+16092815203">
                                            <img class="phone-icon"
                                                src="{{ asset('assets/image/social/phone.png') }}" alt="">
                                            <span>+1 (609) 281 5203</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mailto:info@croxpertz.com">
                                            <img class="mail-icon" src="{{ asset('assets/image/social/mail.png') }}"
                                                alt="">
                                            <span>info@croxpertz.com</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="container-1470">
                    <div class="footer-bottom-flex">
                        <p>©<?php echo date('Y'); ?>. All rights reserved. CROXpertz. Terms & Condition Applied</p>
                        @include('socialicons')
                    </div>
                </div>
            </div>
        </footer>

        <!-- Modal -->
        <div class="modal main-modal get-started-modal fade" id="getstarted" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="StepForm">
                        <div class="main-step-form bg-transparent border-0 mx-auto">
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div class="text-form">
                                <p>Ready to the</p>
                                <h3>Next Level?</h3>
                            </div>
                            <form class="modal-form form1">
                                <input type="hidden" class="page-name" name="page-name"
                                    value="{{ $view_name }}">
                                <input type="hidden" class="price-package" name="price-package" value="">
                                <input type="hidden" class="package-name" name="package-name" value="">
                                <div class="form-group-step">
                                    <input type="text" id="name" name="name" placeholder="Name*"
                                        required>
                                </div>
                                <div class="form-group-step">
                                    <input type="email" id="email" name="email" placeholder="Email Address*"
                                        required>
                                </div>
                                <div class="form-group-step">
                                    <input type="number" id="number" name="phone" placeholder="Phone Number*"
                                        required>
                                </div>
                                <div class="form-group-step">
                                    <textarea placeholder="Your Message*" id="message" name="message" required></textarea>
                                </div>
                                <button type="submit" class="btn-regular orange-btn">
                                    <span>Submit</span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script src="https://unpkg.co/gsap@3/dist/gsap.min.js"></script>
    <script src="https://unpkg.com/gsap@3/dist/ScrollTrigger.min.js"></script>
    <!--<script src="https://unpkg.com/gsap@3/dist/ScrollToPlugin.min.js"></script>-->
    <script src="assets/js/script.js"></script>
    <!--//custom script-->

    <!--Modal-->


    @if (Route::current()->getName() == 'termsandconditions' ||
            Route::current()->getName() == 'privacypolicy' ||
            Route::current()->getName() == 'refundpolicy')
    @else
        <script>
            $(window).on('load', function() {
                setTimeout(function() {
                    $('div#getstarted').modal('show');
                }, 15000);
            });
        </script>
    @endif



    <!--Modal-->

    <script>
        //$('body').on("click",'.step1',function(){
        $('.form1').on('submit', function(e) {

            e.preventDefault();

            let name_data = $(this).find("input[name='name']", this).val();
            let name;
            if (name_data == undefined) {
                name = $(this).find("input[name='fname']", this).val() + ' ' + $(this).find("input[name='lname']",
                    this).val();
            } else if (name_data == 'subscribedField') {
                var mailText = $(this).find("input[name='email']", this).val();
                var arr = mailText.split('@');
                name = arr[0];
            } else {
                name = name_data;
            }
            //alert(name);return;

            let message_data = $(this).find("textarea[name='message']", this).val();
            //alert(message_data);return;
            let company = $(this).find('#company').val();
            let website_url = $(this).find('#website_url').val();
            var serviceofinterestfirst = $(this).find('.serviceofinterest').is(':checked');
            if (serviceofinterestfirst) {
                var serviceofinterest = $(this).find('.serviceofinterest:checked').siblings('label').text();
            }


            let message;
            if (message_data == undefined) {
                message = 'Goal | ' + $(this).find('#goal').val() + ' | Leads |' + $(this).find('#leads').val() +
                    ' | Industry |' + $(this).find('#industry').val() + ' | Countries |' + $(this).find(
                        '#countries').val();
            } else if (serviceofinterest) {
                message = 'Services Of Interest| ' + serviceofinterest + ' | Message | ' + $(this).find(
                    "textarea[name='message']", this).val();
            } else {
                message = $(this).find("textarea[name='message']", this).val();
            }
            //alert(message);return;
            let phone = $(this).find("input[name='phone']", this).val();
            let email = $(this).find("input[name='email']", this).val();


            // let serviceprice=$('.price-package').val();
            let serviceprice = $(this).find("input[name='price-package']", this).val();
            //let servicename=$('.package-name').val();
            let servicename = $(this).find("input[name='package-name']", this).val();
            //let servicetitle=$('.page-name').val();
            let servicetitle = $(this).find("input[name='page-name']", this).val();

            let source = `{{ request()->get('utm_source') ?? '' }}`;
            let campaign = `{{ request()->get('utm_campaign') ?? '' }}`;

            let dat = `{{ Request::getRequestUri('utm_source') }}`;


            // return false;
            $.ajax({
                url: `{{ url('/ajaxForm') }}`,
                method: "post",
                data: {
                    name: name,
                    phone: phone,
                    email: email,
                    message: message,
                    serviceprice: serviceprice,
                    servicename: servicename,
                    servicetitle: servicetitle,
                    source: source,
                    campaign: campaign,
                    dat: dat,
                    company: company,
                    website_url: website_url
                },
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: "json",
                success: function(data) {
                    if (data) {
                        $('#myModal .btn-close').trigger("click");
                        $('input').val('');
                        $('#message').text('');
                        toastr.success(data.msg);
                        setTimeout(function() {
                            window.location.href = "{{ url('/thankyou') }}";
                        }, 1000);

                    } else {
                        toastr.error(data.msg)
                    }
                }
            })
        })
    </script>

    <!-- This site is converting visitors into subscribers and customers with https://respond.io -->
    <script id="respondio__widget"
        src="https://cdn.respond.io/webchat/widget/widget.js?cId=92266f9d4e27f738ae45cbf4ae3385990c0ebbe985397807d3ea20d4915049a1">
    </script><!-- https://respond.io -->
</body>

</html>
