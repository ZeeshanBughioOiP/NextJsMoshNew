

<!-- {{ session('email') }}
{{ session('password') }} -->
@extends('Admin.layout.main')
@section('pageTitle', 'Profile Edit')
@section('main-container')

<style>
        .btn-outline-primary {
            color: #459aff;
            border-color: #459aff;
        }
        .btn-outline-primary:hover {
            color: #459aff;
            border-color: #459aff;
            color: #fff;
            background-color: #459aff;
        }  
        .page-item.active .page-link {
            color: #fff;
            background-color: #459aff;
            border-color: #459aff;
        }
        .page-link {
            position: relative;
            display: block;
            padding: 0.5rem 0.75rem;
            margin-left: -1px;
            line-height: 1.25;
            color: #459aff;
            background-color: #fff;
            border: 1px solid #dee2e6;
        }

        .text-blue {
            color: #459aff;
        }
</style>


<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<div class="page-header">
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="title">
									<h4>Profile Edit</h4>
								</div>
							</div>
						</div>
					</div>
					<!-- Default Basic Forms End -->

					<!-- horizontal Basic Forms Start -->
					<div class="pd-20 card-box mb-30">

                        @if(session('success'))
                      <div class="card-alert card gradient-45deg-green-teal">
                        <div class="card-content white-text">
                          <p>
                            <i class="material-icons">check</i> SUCCESS : {{ session('success') }}</p>
                        </div>
                      </div>
                        @endif


                        @if(session('error'))
                      <div class="card-alert card gradient-45deg-green-teal">
                        <div class="card-content white-text">
                          <p>
                            <i class="material-icons">check</i> SUCCESS : {{ session('error') }}</p>
                        </div>
                      </div>
                        @endif
						<form action="{{route('profileupdate')}}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <?php foreach($data as $d){ ?>

                            
							<div class="form-group">
								<label>User Name</label>
								<input
									class="form-control"
									type="text" name="name"
									placeholder="Name" required value="<?=$d->name; ?>"
								/>
                                <input type="hidden" name="id" value="<?=$d->id; ?>">
                                @if ($errors->has('name'))
                                      <span class="text-danger">{{ $errors->first('name') }}</span>
                                  @endif
							</div>

                            <div class="form-group">
								<label>User Email</label>
								<input
									class="form-control"
									type="email" name="email"
									placeholder="Email" required value="<?=$d->email; ?>"
								/>
                                @if ($errors->has('email'))
                                      <span class="text-danger">{{ $errors->first('email') }}</span>
                                  @endif
							</div>
							
							<div class="form-group">
								<label>Current Password</label>
								<input
									class="form-control"
									type="password" name="current_password"
									placeholder="Current Password" value=""
								/>
                                @if ($errors->has('current_password'))
                                      <span class="text-danger">{{ $errors->first('current_password') }}</span>
                                  @endif
							</div>
							
                            <div class="form-group">
								<label>New Password</label>
								<input
									class="form-control"
									type="password" name="new_password"
									placeholder="New Password" value=""
								/>
                                @if ($errors->has('new_password'))
                                      <span class="text-danger">{{ $errors->first('new_password') }}</span>
                                  @endif
							</div>
							
							<?php } ?>
                            <input class="btn btn-outline-primary" type="submit" name="submit">
						</form>
						<div class="collapse collapse-box" id="horizontal-basic-form1">
							<div class="code-box">
								<pre><code class="xml copy-pre" id="horizontal-basic">
</code></pre>
							</div>
						</div>
					</div>
					<!-- horizontal Basic Forms End -->

					<!-- Form grid Start -->
					<!-- <div class="pd-20 card-box mb-30">
						<div class="clearfix">
							<div class="pull-left">
								<h4 class="text-blue h4">Form grid</h4>
								<p class="mb-30">All bootstrap element classies</p>
							</div>
							<div class="pull-right">
								<a
									href="#form-grid-form"
									class="btn btn-primary btn-sm scroll-click"
									rel="content-y"
									data-toggle="collapse"
									role="button"
									><i class="fa fa-code"></i> Source Code</a
								>
							</div>
						</div> -->
						<!-- <form>
							<div class="row">
								<div class="col-md-4 col-sm-12">
									<div class="form-group">
										<label>col-md-4</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-4 col-sm-12">
									<div class="form-group">
										<label>col-md-4</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-4 col-sm-12">
									<div class="form-group">
										<label>col-md-4</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 col-sm-12">
									<div class="form-group">
										<label>col-md-6</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-6 col-sm-12">
									<div class="form-group">
										<label>col-md-6</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 col-sm-12">
									<div class="form-group">
										<label>col-md-6</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<div class="form-group">
										<label>col-md-12</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
						</form> -->
						<div class="collapse collapse-box" id="form-grid-form">
							<div class="code-box">
								<pre><code class="xml copy-pre" id="form-grid">
<!-- <form>
	<div class="row">
		<div class="col-md-4 col-sm-12">
			<div class="form-group">
				<label>col-md-4</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-4 col-sm-12">
			<div class="form-group">
				<label>col-md-4</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-4 col-sm-12">
			<div class="form-group">
				<label>col-md-4</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<div class="form-group">
				<label>col-md-6</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-6 col-sm-12">
			<div class="form-group">
				<label>col-md-6</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<div class="form-group">
				<label>col-md-6</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 col-sm-12">
			<div class="form-group">
				<label>col-md-12</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
</form> -->
							</code></pre>
							</div>
						</div>
					</div>
					<!-- Form grid End -->

					<!-- Input Validation Start -->
					<div class="pd-20 card-box mb-30">
						<!-- <div class="clearfix">
							<div class="pull-left">
								<h4 class="text-blue h4">Input Validation</h4>
								<p class="mb-30">
									Validation styles for error, warning, and success
								</p>
							</div>
							<div class="pull-right">
								<a
									href="#input-validation-form"
									class="btn btn-primary btn-sm scroll-click"
									rel="content-y"
									data-toggle="collapse"
									role="button"
									><i class="fa fa-code"></i> Source Code</a
								>
							</div>
						</div>
						<form>
							<div class="row">
								<div class="col-md-6 col-sm-12">
									<div class="form-group has-success">
										<label class="form-control-label">Input with success</label>
										<input
											type="text"
											class="form-control form-control-success"
										/>
										<div class="form-control-feedback">
											Success! You've done it.
										</div>
										<small class="form-text text-muted"
											>Example help text that remains unchanged.</small
										>
									</div>
									<div class="form-group has-warning">
										<label class="form-control-label">Input with warning</label>
										<input
											type="text"
											class="form-control form-control-warning"
										/>
										<div class="form-control-feedback">
											Shucks, check the formatting of that and try again.
										</div>
										<small class="form-text text-muted"
											>Example help text that remains unchanged.</small
										>
									</div>
									<div class="form-group has-danger">
										<label class="form-control-label">Input with danger</label>
										<input
											type="text"
											class="form-control form-control-danger"
										/>
										<div class="form-control-feedback">
											Sorry, that username's taken. Try another?
										</div>
										<small class="form-text text-muted"
											>Example help text that remains unchanged.</small
										>
									</div>
								</div>
								<div class="col-md-6 col-sm-12">
									<div class="form-group has-success row">
										<label
											class="form-control-label col-sm-12 col-md-3 col-form-label"
											>Input with success</label
										>
										<div class="col-sm-12 col-md-9">
											<input
												type="text"
												class="form-control form-control-success"
											/>
											<div class="form-control-feedback">
												Success! You've done it.
											</div>
											<small class="form-text text-muted"
												>Example help text that remains unchanged.</small
											>
										</div>
									</div>
									<div class="form-group has-warning row">
										<label
											class="form-control-label col-sm-12 col-md-3 col-form-label"
											>Input with warning</label
										>
										<div class="col-sm-12 col-md-9">
											<input
												type="text"
												class="form-control form-control-warning"
											/>
											<div class="form-control-feedback">
												Shucks, check the formatting of that and try again.
											</div>
											<small class="form-text text-muted"
												>Example help text that remains unchanged.</small
											>
										</div>
									</div>
									<div class="form-group has-danger row">
										<label
											class="form-control-label col-sm-12 col-md-3 col-form-label"
											>Input with danger</label
										>
										<div class="col-sm-12 col-md-9">
											<input
												type="text"
												class="form-control form-control-danger"
											/>
											<div class="form-control-feedback">
												Sorry, that username's taken. Try another?
											</div>
											<small class="form-text text-muted"
												>Example help text that remains unchanged.</small
											>
										</div>
									</div>
								</div>
							</div>
						</form> -->
						<div class="collapse collapse-box" id="input-validation-form">
							<div class="code-box">
								<pre><code class="xml copy-pre" id="input-validation">
							</code></pre>
							</div>
						</div>
					</div>
					<!-- Input Validation End -->
				</div>
			</div>
		</div>





@endsection