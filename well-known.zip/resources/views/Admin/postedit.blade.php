

<!-- {{ session('email') }}
{{ session('password') }} -->
@extends('Admin.layout.main')
@section('pageTitle', 'Post Edit')
@section('main-container')

<style>
        .btn-outline-primary {
            color: #459aff;
            border-color: #459aff;
        }
        .btn-outline-primary:hover {
            color: #459aff;
            border-color: #459aff;
            color: #fff;
            background-color: #459aff;
        }  
        .page-item.active .page-link {
            color: #fff;
            background-color: #459aff;
            border-color: #459aff;
        }
        .page-link {
            position: relative;
            display: block;
            padding: 0.5rem 0.75rem;
            margin-left: -1px;
            line-height: 1.25;
            color: #459aff;
            background-color: #fff;
            border: 1px solid #dee2e6;
        }

        .text-blue {
            color: #459aff;
        }
</style>


<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<!-- Default Basic Forms Start -->
					<!-- Default Basic Forms End -->

					<!-- horizontal Basic Forms Start -->
					<div class="pd-20 card-box mb-30">
						<div class="clearfix">
							<div class="pull-left">
								<h4 class="text-blue h4">Blog Edit</h4>
							</div>
						</div>
						<form action="{{route('postupdate')}}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <?php foreach($data as $d){ ?>

                            
							<div class="form-group">
								<label>Blog Name</label>
								<input
									class="form-control"
									type="text" name="post_name"
									placeholder="Post Name" required value="<?=$d->post_name; ?>"
								/>
                                <input type="hidden" name="id" value="<?=$d->post_id; ?>">
                                @if ($errors->has('post_name'))
                                      <span class="text-danger">{{ $errors->first('post_name') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Slug Name</label>
								<input class="form-control" type="text" name="slug_name" placeholder="Slug Name" required value="<?=$d->slug_name; ?>"/>
                                @if ($errors->has('slug_name'))
                                      <span class="text-danger">{{ $errors->first('slug_name') }}</span>
                                  @endif
							</div>
							<div class="form-group">
                                <label>Category</label>
                                <select name="category" class="form-control" required>
                                    <option value="">Select Category</option>
                                    <option value="lead_generation" <?php echo ($d->category == 'lead_generation') ? 'selected' : '' ?>>Lead Generation</option>
                                    <option value="traffic_optimization" <?php echo ($d->category == 'traffic_optimization') ? 'selected' : '' ?>>Traffic Optimization</option>
                                    <option value="ecommerce_optimization" <?php echo ($d->category == 'ecommerce_optimization') ? 'selected' : '' ?>>Ecommerce Optimization</option>
                                    <option value="brand_engagement" <?php echo ($d->category == 'brand_engagement') ? 'selected' : '' ?>>Brand Engagement</option>
                                    <option value="appointment_scheduling" <?php echo ($d->category == 'appointment_scheduling') ? 'selected' : '' ?>>Appointment Scheduling</option>
                                    <option value="app_marketing_agency" <?php echo ($d->category == 'app_marketing_agency') ? 'selected' : '' ?>>App Marketing Agency</option>
                                    <option value="others" <?php echo ($d->category == 'others') ? 'selected' : '' ?>>Others</option>
                                </select>
                                @if ($errors->has('category'))
                                        <span class="text-danger">{{ $errors->first('category') }}</span>
                                    @endif
                            </div> 
							<div class="form-group">
								<label>Blog Short Description</label>
								<!--<textarea class="ckeditorTn1 form-control" name="post_short_description" required maxlength="100"><?=$d->post_short_description; ?></textarea>-->
								<textarea class="ckeditorzee form-control" name="post_short_description" required maxlength="100"><?=$d->post_short_description; ?></textarea>
                                @if ($errors->has('post_short_description'))
                                      <span class="text-danger">{{ $errors->first('post_short_description') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Blog Long Description</label>
								<!--<textarea class="ckeditorTn2 form-control" name="post_description" required maxlength="100"><?=$d->post_description; ?></textarea>-->
								<textarea class="ckeditorzee2 form-control" name="post_description" required maxlength="100"><?=$d->post_description; ?></textarea>
                                @if ($errors->has('post_description'))
                                      <span class="text-danger">{{ $errors->first('post_description') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Meta Title</label>
								<input class="form-control" type="text" name="meta_title" placeholder="Meta Title" required value="<?=$d->meta_title; ?>"/>
                                @if ($errors->has('meta_title'))
                                      <span class="text-danger">{{ $errors->first('meta_title') }}</span>
                                  @endif
							</div>
								<div class="form-group">
								<label>Meta Keyword</label>
								<input class="form-control" type="text" name="meta_keyword"  placeholder="Meta Keyword" required value="<?=$d->meta_keyword; ?>"/>
                                @if ($errors->has('meta_keyword'))
                                      <span class="text-danger">{{ $errors->first('meta_keyword') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Meta Description</label>
								<input class="form-control" type="text" name="meta_description" placeholder="Meta Description" required value="<?=$d->meta_description; ?>"/>
                                @if ($errors->has('meta_description'))
                                      <span class="text-danger">{{ $errors->first('meta_description') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Upload Blog Image</label>
								<input
									type="file" name="image"
									class="form-control-file form-control height-auto"
								/>
                                <img src="<?=url('uploads/apifileregistration/'.$d->post_image); ?>" style="width: 30%;" >

							</div>
							<?php } ?>
                            <input class="btn btn-outline-primary" type="submit" name="submit">
						</form>
						<div class="collapse collapse-box" id="horizontal-basic-form1">
							<div class="code-box">
								<pre><code class="xml copy-pre" id="horizontal-basic">
<form>
	<div class="form-group">
		<label>Text</label>
		<input class="form-control" type="text" placeholder="Johnny Brown">
	</div>
	
	<div class="form-group">
		<label>Example file input</label>
		<input type="file" class="form-control-file form-control height-auto">
	</div>

</form>

</code></pre>
							</div>
						</div>
					</div>
					<!-- horizontal Basic Forms End -->

					<!-- Form grid Start -->
					<!-- <div class="pd-20 card-box mb-30">
						<div class="clearfix">
							<div class="pull-left">
								<h4 class="text-blue h4">Form grid</h4>
								<p class="mb-30">All bootstrap element classies</p>
							</div>
							<div class="pull-right">
								<a
									href="#form-grid-form"
									class="btn btn-primary btn-sm scroll-click"
									rel="content-y"
									data-toggle="collapse"
									role="button"
									><i class="fa fa-code"></i> Source Code</a
								>
							</div>
						</div> -->
						<!-- <form>
							<div class="row">
								<div class="col-md-4 col-sm-12">
									<div class="form-group">
										<label>col-md-4</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-4 col-sm-12">
									<div class="form-group">
										<label>col-md-4</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-4 col-sm-12">
									<div class="form-group">
										<label>col-md-4</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 col-sm-12">
									<div class="form-group">
										<label>col-md-6</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-6 col-sm-12">
									<div class="form-group">
										<label>col-md-6</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 col-sm-12">
									<div class="form-group">
										<label>col-md-6</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-3 col-sm-12">
									<div class="form-group">
										<label>col-md-3</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<div class="form-group">
										<label>col-md-12</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
								<div class="col-md-2 col-sm-12">
									<div class="form-group">
										<label>col-md-2</label>
										<input type="text" class="form-control" />
									</div>
								</div>
							</div>
						</form> -->
						<div class="collapse collapse-box" id="form-grid-form">
							<div class="code-box">
								<pre><code class="xml copy-pre" id="form-grid">
<!-- <form>
	<div class="row">
		<div class="col-md-4 col-sm-12">
			<div class="form-group">
				<label>col-md-4</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-4 col-sm-12">
			<div class="form-group">
				<label>col-md-4</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-4 col-sm-12">
			<div class="form-group">
				<label>col-md-4</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<div class="form-group">
				<label>col-md-6</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-6 col-sm-12">
			<div class="form-group">
				<label>col-md-6</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<div class="form-group">
				<label>col-md-6</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-3 col-sm-12">
			<div class="form-group">
				<label>col-md-3</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 col-sm-12">
			<div class="form-group">
				<label>col-md-12</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="col-md-2 col-sm-12">
			<div class="form-group">
				<label>col-md-2</label>
				<input type="text" class="form-control">
			</div>
		</div>
	</div>
</form> -->
							</code></pre>
							</div>
						</div>
					</div>
					<!-- Form grid End -->

					<!-- Input Validation Start -->
					<div class="pd-20 card-box mb-30">
						<!-- <div class="clearfix">
							<div class="pull-left">
								<h4 class="text-blue h4">Input Validation</h4>
								<p class="mb-30">
									Validation styles for error, warning, and success
								</p>
							</div>
							<div class="pull-right">
								<a
									href="#input-validation-form"
									class="btn btn-primary btn-sm scroll-click"
									rel="content-y"
									data-toggle="collapse"
									role="button"
									><i class="fa fa-code"></i> Source Code</a
								>
							</div>
						</div>
						<form>
							<div class="row">
								<div class="col-md-6 col-sm-12">
									<div class="form-group has-success">
										<label class="form-control-label">Input with success</label>
										<input
											type="text"
											class="form-control form-control-success"
										/>
										<div class="form-control-feedback">
											Success! You've done it.
										</div>
										<small class="form-text text-muted"
											>Example help text that remains unchanged.</small
										>
									</div>
									<div class="form-group has-warning">
										<label class="form-control-label">Input with warning</label>
										<input
											type="text"
											class="form-control form-control-warning"
										/>
										<div class="form-control-feedback">
											Shucks, check the formatting of that and try again.
										</div>
										<small class="form-text text-muted"
											>Example help text that remains unchanged.</small
										>
									</div>
									<div class="form-group has-danger">
										<label class="form-control-label">Input with danger</label>
										<input
											type="text"
											class="form-control form-control-danger"
										/>
										<div class="form-control-feedback">
											Sorry, that username's taken. Try another?
										</div>
										<small class="form-text text-muted"
											>Example help text that remains unchanged.</small
										>
									</div>
								</div>
								<div class="col-md-6 col-sm-12">
									<div class="form-group has-success row">
										<label
											class="form-control-label col-sm-12 col-md-3 col-form-label"
											>Input with success</label
										>
										<div class="col-sm-12 col-md-9">
											<input
												type="text"
												class="form-control form-control-success"
											/>
											<div class="form-control-feedback">
												Success! You've done it.
											</div>
											<small class="form-text text-muted"
												>Example help text that remains unchanged.</small
											>
										</div>
									</div>
									<div class="form-group has-warning row">
										<label
											class="form-control-label col-sm-12 col-md-3 col-form-label"
											>Input with warning</label
										>
										<div class="col-sm-12 col-md-9">
											<input
												type="text"
												class="form-control form-control-warning"
											/>
											<div class="form-control-feedback">
												Shucks, check the formatting of that and try again.
											</div>
											<small class="form-text text-muted"
												>Example help text that remains unchanged.</small
											>
										</div>
									</div>
									<div class="form-group has-danger row">
										<label
											class="form-control-label col-sm-12 col-md-3 col-form-label"
											>Input with danger</label
										>
										<div class="col-sm-12 col-md-9">
											<input
												type="text"
												class="form-control form-control-danger"
											/>
											<div class="form-control-feedback">
												Sorry, that username's taken. Try another?
											</div>
											<small class="form-text text-muted"
												>Example help text that remains unchanged.</small
											>
										</div>
									</div>
								</div>
							</div>
						</form> -->
					</div>
					<!-- Input Validation End -->
				</div>
			</div>
		</div>





@endsection