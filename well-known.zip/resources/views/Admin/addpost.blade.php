@extends('Admin.layout.main')
@section('pageTitle', 'Post Add')
@section('main-container')


<style>
        .btn-outline-primary {
            color: #459aff;
            border-color: #459aff;
        }
        .btn-outline-primary:hover {
            color: #459aff;
            border-color: #459aff;
            color: #fff;
            background-color: #459aff;
        }  
</style>

<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<div class="page-header">
					<h4 class="text-blue h4">Add New Blog</h4>
					</div>
					<div class="pd-20 card-box mb-30">
						<form action="{{route('savepost')}}" method="POST" enctype="multipart/form-data">
                            @csrf
							<div class="form-group">
								<label>Blog Title</label>
								<input
									class="form-control"
									type="text" name="post_name"
									placeholder="Blog Title" required
								/>
                                @if ($errors->has('post_name'))
                                      <span class="text-danger">{{ $errors->first('post_name') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Slug Name</label>
								<input class="form-control" type="text" name="slug_name"  placeholder="Use Slug-Name" required/>
                                @if ($errors->has('slug_name'))
                                      <span class="text-danger">{{ $errors->first('slug_name') }}</span>
                                  @endif
							</div>
							<div class="form-group">
                                <label>Category</label>
                                <select name="category" class="form-control" required>
                                    <option value="">Select Category</option>
                                    <option value="lead_generation">Lead Generation</option>
                                    <option value="traffic_optimization">Traffic Optimization</option>
                                    <option value="ecommerce_optimization">Ecommerce Optimization</option>
                                    <option value="brand_engagement">Brand Engagement</option>
                                    <option value="appointment_scheduling">Appointment Scheduling</option>
                                    <option value="app_marketing_agency">App Marketing Agency</option>
                                    <option value="others">Others</option>
                                </select>
                                @if ($errors->has('category'))
                                        <span class="text-danger">{{ $errors->first('category') }}</span>
                                    @endif
                            </div> 
							<div class="form-group">
								<label>Blog Short Description</label>
								<!--<textarea class="ckeditorTn1 form-control" name="post_short_description" maxlength="10"></textarea>-->
								<textarea class="ckeditorzee form-control" name="post_short_description" maxlength="10"></textarea>
                                @if ($errors->has('post_short_description'))
                                      <span class="text-danger">{{ $errors->first('post_short_description') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Blog Long Description</label>
								<!--<textarea class="ckeditorTn2 form-control" name="post_description" maxlength="10"></textarea>-->
								<textarea class="ckeditorzee2 form-control" name="post_description" maxlength="10"></textarea>
                                @if ($errors->has('post_description'))
                                      <span class="text-danger">{{ $errors->first('post_description') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Meta Title</label>
								<input class="form-control" type="text" name="meta_title"  placeholder="Meta Title" required/>
                                @if ($errors->has('meta_title'))
                                      <span class="text-danger">{{ $errors->first('meta_title') }}</span>
                                  @endif
							</div>
								<div class="form-group">
								<label>Meta Keyword</label>
								<input class="form-control" type="text" name="meta_keyword"  placeholder="Meta Keyword" required/>
                                @if ($errors->has('meta_keyword'))
                                      <span class="text-danger">{{ $errors->first('meta_keyword') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Meta Description</label>
								<input class="form-control" type="text" name="meta_description"  placeholder="Meta Description" required/>
                                @if ($errors->has('meta_description'))
                                      <span class="text-danger">{{ $errors->first('meta_description') }}</span>
                                  @endif
							</div>
							<div class="form-group">
								<label>Upload Blog Image</label>
								<input
									type="file" name="image"
									class="form-control-file form-control height-auto" required
								/>
							</div>
                            <input class="btn btn-outline-primary" type="submit" name="submit">
						</form>
						<div class="collapse collapse-box" id="horizontal-basic-form1">
							<div class="code-box">
								<div class="clearfix">
									<a
										href="javascript:;"
										class="btn btn-primary btn-sm code-copy pull-left"
										data-clipboard-target="#horizontal-basic"
										><i class="fa fa-clipboard"></i> Copy Code</a
									>
									<a
										href="#horizontal-basic-form1"
										class="btn btn-primary btn-sm pull-right"
										rel="content-y"
										data-toggle="collapse"
										role="button"
										><i class="fa fa-eye-slash"></i> Hide Code</a
									>
								</div>
								<pre><code class="xml copy-pre" id="horizontal-basic">
<form>
	<div class="form-group">
		<label>Text</label>
		<input class="form-control" type="text" placeholder="Johnny Brown">
	</div>
	<div class="form-group">
		<label>Textarea</label>
		<textarea class="form-control"></textarea>
	</div>
	<div class="form-group">
		<label>Example file input</label>
		<input type="file" class="form-control-file form-control height-auto">
	</div>
</form>

</code></pre>
							</div>
						</div>
					</div>
					<div class="pd-20 card-box mb-30">
						<div class="collapse collapse-box" id="input-validation-form">
							<div class="code-box">
								<div class="clearfix">
									<a
										href="javascript:;"
										class="btn btn-primary btn-sm code-copy pull-left"
										data-clipboard-target="#input-validation"
										><i class="fa fa-clipboard"></i> Copy Code</a
									>
									<a
										href="#input-validation-form"
										class="btn btn-primary btn-sm pull-right"
										rel="content-y"
										data-toggle="collapse"
										role="button"
										><i class="fa fa-eye-slash"></i> Hide Code</a
									>
								</div>
								<pre><code class="xml copy-pre" id="input-validation">
							</code></pre>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>


   
<!--<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>-->
<!--<script type="text/javascript">-->
<!--    $(document).ready(function() {-->
<!--       $('.ckeditor').ckeditor();-->
<!--    });-->
<!--</script>-->


@endsection