@extends('front.app')

@section('title','Terms & Condition')
@section('metadescription','')
@section('keywords', '')
@section('content')

        <section class="banner-section-services background-after-image-blurred banner-privacy">
            <div class="before-image-banner position-relative">
                <a href="#sec2" class="secdown">
                    <p>Scroll to explore</p>
                    <span><img src="{{asset('assets/image/ArrowULeftDown.png')}}" alt=""></span>
                </a>
                <div class="container-1470 position-relative">
                    <div class="banner-flex">
                        <div class="image-banner-left image-banner">
                            <img src=" {{asset('assets/image/terms.png')}}" alt="">
                        </div>
                        <div class="banner-content-services">
                            <div>
                                <h1>Terms & <br>Conditions</h1>
                                <p>By using CROxpertz's website and services, you agree to be bound by these Terms and Conditions. If you do not agree, please do not use our website or services.</p>
                                <a class="btn-regular orange-btn btn-weight-medium" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                                @include('socialicons')
                            </div>
                        </div>
                        <div class="image-banner-right image-banner">
                            <img src=" {{asset('assets/image/terms2.png')}}" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="sec2" class="pptcrf">
            <div class="container-1470">
                <div class="wrapping">
                    <h2 class="mb-20 fa-50">TERMS OF USE</h2>
                    <p class="fa-18 mb-20">The decision of visiting our website, landing pages and availing our service is exclusively your choice. Any argument about protection is dependent upon our Privacy Policy and our Conditions of Use. This incorporates constraints on harms, mediation of questions, and the material law of state. On the off chance that the customer has any issues in regards to the Privacy Policy, they should get in touch with us through our contact information given on the website.</p>
                    <p class="fa-18 mb-20">We own the rights to change our policies at any time. Therefore, we suggest that our visitors and customers thoroughly read the policy before they enter the website or avail any of our services.</p>
                    <p class="fa-18 mb-20">We collect personal information and data about where guests go on our site, what pages they visit, how much time they spent on the pages and more. This data enables us to see which of our pages or services are most visited and helps us improve our services and understand our customers. We own the complete rights of all materials, including pictures, representations, plans, symbols, photos, content and different materials that are a part of this Site.</p>
                    <p class="fa-18 mb-20">The customer may download or duplicate the Contents and other downloadable materials showed on the Site for their personal use as it were. No right, title or enthusiasm for any downloaded materials or programming is moved to the customer because of any such downloading or duplicating. The customer may not replicate (with the exception of as noted above), distribute, transmit, convey, show, alter, make subordinates, sell or partake in any deal or misuse of the site, its substance, or any related programming.</p>                 
                    <h2 class=" mb-20 fa-50 pdt-50">Testimonials</h2>
                    <p class="fa-18 mb-20">All remarks, feedback, recommendations, thoughts, and different entries revealed, submitted or offered to Our Company on or by this Site or generally unveiled, submitted or offered regarding your utilization of this Site (all things considered, the "Remarks") will remain the Company's property.</p>
                    <p class="fa-18 mb-20">The Company will claim complete rights, titles and interests and will not be constrained at all in its utilization, business or something else, with reference to the Comments. The Company is and will be under no commitment:</p>
                    <ol class="fa-18 mb-20 for-terms-condtion">
                        <li> To keep up any Comments in certainty;</li>
                        <li> To pay clients for any Comments; or</li>
                        <li> To react to any client Comments.</li>
                    </ol>
                    <p class="fa-18 mb-20">The organization can likewise utilize the tributes and logos of the customers on its other web and disconnected properties.</p>
                    <h2 class="mb-20 fa-50 pdt-50">Electronic Communications</h2>
                    <p class="fa-18 mb-20">Any time the customer visits our site or sends messages to us, the customer is communicating with our organization electronically. It's automatic for the customer to get our correspondences electronically. Our Company will speak with the customer by email or by posting on this site. Hence the customer concurs that all understandings, notification, divulgences and significant correspondence fulfill and satisfy every legitimate prerequisite and are proportionate to any lawful explanation recorded as a hard copy.</p>
                    <p class="fa-18 mb-20">Information regarding any cooperation between CRO and you or your employer (such as requesting specifications for products we’ve developed and/or services we have provided to you or your employer);</p>
                    <h2 class="mb-20 fa-50 pdt-50">Copyright / Trademarks</h2>
                    <p class="fa-18 mb-20">All the material that is incorporated on this website, for example, content, designs, logos, buttons and their symbols, pictures, downloads, information arrangements, and programming, is the property of this organization or its substance providers and ensured according to the copyright laws. All products utilized at this site is the property of this organization or its product providers and ensured according to global copyright laws.</p>
                    <p class="fa-18 mb-20">The trademark names utilized inside our destinations are the property of their individual organization or its auxiliaries and can't be utilized regarding any item or administration that isn't a piece of that organization.</p>
                    <h2 class="mb-20 fa-50 pdt-50">Copyright Complaints</h2>
                    <p class="fa-18 mb-20">The Company and its partners respect the licensed property of others. On the off chance that anybody perusing the site accepts that their work has been replicated in a manner that establishes copyright encroachment, please follow the procedure to making your claim.</p>
                    <h2 class="mb-20 fa-50 pdt-50">Revision Policy</h2>
                    <p class="fa-18 mb-20">CRO Xpertz will provide full refund if the project has not been started for the next 20 days of purchase. However, this policy can be terminated at any point of time regardless of the scenario and this only implies if the request is made upon viewing the initial concepts only (less the 10% processing fee). Furthermore, any revisions requested after viewing the initial concepts will void this offer and would be considered as continuation of the project.</p>
                 
                    <ol class="fa-18 mb-20 for-up-roman">
                    <li>The refund policy will not be applicable on any discounted offer.</li>
                    <li>The refund policy will not be applicable if the customer has been unresponsive for more than 20 days.</li>
                    <li>The customer can always request to get his project held for a certain period of time, however, refund won’t be applicable on such situation.</li>
                    <li>The refund will be voided if the refund is requested, over situations not related to the company such as, the business shutting down or partner not agreeing on the design or any scenarios not related to the company.</li>
                    <li>Urgent design projects are non-refundable.</li>
                    <li>The company will not refund any client whose work was outsourced to CRO Xpertz by a third party.</li>
                    <li>If the refund has been processed, the customer or the entity will have zero authority to use any source of work design that has been shared with the client. If found, it will be a breach of contract and legal proceedings will be acted upon.</li>
                    <li>The client will not be refunded any money after the payment has been disputed. Any of such scenarios will lead to termination of the contract.</li>
                    <li>The client can always reach out to CRO Xpertz in case of any difference between the contract and the commitments made with the client.</li>
                    <li>In case of duplicate charges, the 100% refund will be implied on such scenarios.</li>
                    </ol>
                    <p class="fa-18 mb-20 "> Note: The refund will take 10-15 days after the cancellation request. However, the client will not use any of the provided work shared with the client. In case of bundle purchases, the service in question will be refunded only.</p>
                    <p class="fa-18 mb-20">You can use the following ways to make sure that you refund is made.</p>
                     <ol class="fa-18 mb-20 for-num">
                    <li>Call us</li>
                    <li>Click Live chat to start chatting with our representative</li>
                    <li>Email us</li>
                     </ol>
                     <p class="fa-18 mb-20">Once the refund is made, CRO Xpertz will be the rightful owner of your designs.</p>
                     <h2 class="mb-20 fa-50 pdt-50">Delivery Policy</h2>
                     <p class="fa-18 mb-20">Our promise of unlimited revisions is guaranteed. Revision turnaround time is 48 hours.</p>
                     <p class="fa-18 mb-20">Bill of Rights If you choose to partake in any activity or purchase any of our services, you are among the various customers who have safely and securely made purchases from us. You can place your order via call, email, or live chat. You can unsubscribe from our emails any time you want. If we make any changes to our website, or our services, we will immediately notify you through email. </p>
                     <h2 class="mb-20 fa-50 pdt-50">INFORMATION SECURITY POLICY</h2>
                     <p class="fa-18 mb-20">CRO believes information management is an essential part of good IT governance. Information security is a key component of CRO’s overall security management framework, including system level security policies and security guidance.</p>
                     <p class="fa-18 mb-20">Information security enables us to provide the best possible services on the market. CRO has defined information security policy documentation that is available to our customers upon request. Our core principles for information security management rely on international security policy definitions that are adapted as necessary to the local situation for the following areas:</p>
                     <ul class="fa-18 for-list mb-20">
                    <li>Risk management</li>
                    <li>Organizing information security</li>
                    <li>Human resource security</li>
                    <li>Communications and operations management</li>
                    <li>System development and maintenance</li>
                    <li>Information security incident management</li>
                    <li>Business continuity management</li>
                     <li>Compliance</li>
                     </ul>
                    <p class="fa-18 mb-20">Our information security policy is also compliant with the laws and regulations of Pakistan.</p>
                     <h2 class="mb-20 fa-50 pdt-50">E-mail security</h2>
                    <p class="fa-18 mb-20">CRO treats that all e-mails received and sent must be kept confidential and can only be accessed by the persons indicated in the e-mails.</p>
                    <p class="fa-18 mb-20">The e-mails services used by CRO meet the data security requirements of the business.</p>
                    <p class="fa-18 mb-20">CRO connects to the electronical mailboxes with a secure and recognized SSL / TLS protocol that ensures reliable information encryption. Also, electronical mailboxes are protected against spam.</p>
                    <p class="fa-18 mb-20">All outgoing and incoming e-mails are encrypted, so there is a small possibility that it could be taken over by third parties.</p>
                    <p class="fa-18 mb-20">So, you can safely send e-mails to us and open e-mails where the sender is CRO.</p>
        </div>
    </section>
    

        </section>


@endsection