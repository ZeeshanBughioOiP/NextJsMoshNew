@extends('front.app')

@section('title','Blogs')
@section('metadescription','Blogs')
@section('keywords','blogs')

@section('content')
    
    <!-- Section 1 -->
    
    <section class="banner-blogs">
        <div class="banner-blogs-img-details">
            <img src="{{asset('assets/blogs/performance-marketing.jpg')}}" alt="">
        </div>
        
        <div class="container-1560">
            <h2 class="fa-90 text-white line-height-104 letter-spacing-5 position-relative d-inline-block">Performance Marketing</h2>
        </div>
        
    </section>
    
    <!-- Section 1 Ends -->

    <!-- section 3  -->

    <section class="position-relative our-blogs ">
        <div class="container-1560">
            <div class="blog-details">
                    <p >SEO is all about staying relevant in terms of Google searches and engaging with the audience by optimizing your website. It is an organic way of increasing traffic on the website, which by no means is dying. </p>
                    <p >Like everything SEO has its limitations and sticking to outdated strategies is not going to increase your audience reach. Your potential is only a few steps because if you think that SEO is not working for you, straightening up a few tactics might help your page.</p>
                    <p >The straight fact is that SEO takes time to rank and converge with the target audience since it is an unpaid form of increasing traffic. Google has certain criteria, which have to be taken care of while writing and uploading all the content for your website. </p>
                    <h6 class="list-items-upcoming-heading">Here are some of the mistakes that might be decreasing the overall optimization of your website:</h6>
                    <ul >
                        <li >
                            <span>Obsessing over the number #1 spot:</span>
                            This digital era has forced us to only be the best, or be nothing which is something you shouldn’t believe in! Stop obsessing over the number #1 spot because SEO is constantly evolving, which means that as long as your data is relevant, the audience will find its way! 
                        </li>
                        <li >
                            <span>Hijacking all-in links:</span>
                            On an average SEO can take 4-6 months to kick-start and target the audience, but this doesn’t mean that you start jumbling it up with all-in on links. SEO is a long-term plan, there is no short-cut way to get your site to rank.
                        </li>
                        <li >
                            <span>Over-optimization of one keyword:</span>
                            Search engines are getting smarter by the day which means that over-optimization will get caught. The best ranking comes when the content is relevant and relates to the website without being too patronizing.
                        </li>
                        <li >
                            <span>Believing in ‘bigger is better’:</span>
                            A big website is something no one wants to splurge through to simply understand your business. Let’s be real, we are all in a hurry, and need fast and short information which is why loading up websites is useless. Optimize one page so well that you simply do not have to make other extra efforts!
                        </li>
                        <li >
                            <span>Focusing on irrelevant data:</span>
                            The best thing you can do regardless of constantly putting excessive content out is useful information that the audience is coming for building a strong, more relevant website.
                        </li>
                    </ul>
                    <p> Search engine optimization is not dying, it is simply changing with every passing day and needs innovation and creativity like every other project! Every company wants to make money, and Google is no exception. As a result, the criteria is becoming increasingly difficult. Similarly, LinkedIn is now focusing on paid advertising, limiting inboxes and organic business development methods.</p>
                </div>
        </div>
    </section>


@endsection


