<html>
    <head>
        <title>Croxpertz</title>
    </head>
<body>
    <div class="container">
        <div>
            <h5>Auto genereated email from Croxpertz </h5><br>
        </div>
        
        <div class="col-md-4">
            <div class="form-group">
                <label>Name</label> : <span>{{$name??''}}</span>
          

            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>User Id</label> : <span>{{$email??''}}</span>
          

            </div>
        </div>
        <!--<div class="col-md-4">-->
        <!--    <div class="form-group">-->
        <!--        <label>password</label> : <span>{{$password??''}}</span>-->
             
        <!--    </div>-->
        <!--</div>-->

        <div class="col-md-4">
            <div class="form-group">
                <label>Phone</label>:<span>{{$phone??''}}</span>
               
            </div>
        </div>
        <?php if(!empty($sms)){ ?>
        <div class="col-md-4">
            <div class="form-group">
                <label>Message</label>:<span>{{ $sms??'' }}</span>
               
            </div>
        </div>
        <?php } ?>
        <?php if(!empty($service_interest)){ ?>
        <div class="col-md-4">
            <div class="form-group">
                <label>Services Of Interest</label>:<span>{{ $service_interest??'' }}</span>
               
            </div>
        </div>
        <?php } ?>
        
        <?php if(empty($sms)){ ?>
        <div class="col-md-4">
            <div class="form-group">
                <label>Goal</label>:<span>{{ $goal??'' }}</span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Leads</label>:<span>{{ $leads??'' }}</span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Industry</label>:<span>{{ $industry??'' }}</span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Countries</label>:<span>{{ $countries??'' }}</span>
               
            </div>
        </div>
        <?php } ?>
        
          <div class="col-md-4">
            <div class="form-group">
                <label>Package Name</label> : <span>{{ $package_name??'' }}</span>
               
            </div>
        </div>
        
         <div class="col-md-4">
            <div class="form-group">
                <label>Package Price</label>  : <span>{{ $package_price??'' }}</span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Company Name:</label>  : <span>{{ $company??'' }}</span>
               
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Website url</label>  : <span>{{ $website_url??'' }}</span>
               
            </div>
        </div>
        
        
        
         <div class="col-md-4">
            <div class="form-group">
                <label>URL</label> : <span>{{ 'https://croxpertz.com'.$URL??'' }}</span>
               
            </div>
        </div>


        <!--<div class="col-md-4">-->
        <!--    <div class="form-group">-->
        <!--        <label>Link</label><span>{{$link??''}}</span>-->
               
        <!--    </div>-->
        <!--</div>-->

       

        <div class="col-md-4">
            <div class="form-group">
                <label>Ip</label><span>{!! $ip !!}</span>
               
            </div>
        </div>



    </div>
</body>

</html>