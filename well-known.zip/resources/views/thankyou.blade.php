<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title property="title">Thank You - CROXpertz</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta property="description" name="description" content="@yield('metadesciption')">
    <meta name="keywords" content="CROxpertz">
    
    
    <meta name="robots" content="noindex, nofollow">
    <link rel="icon" href="assets/image/fav-icon.png" type="image/x-icon">
    <meta property="og:site_name" content="CROXpertz">
    <meta property="og:title" content="CROXpertz">
    <meta property="og:description" content="@yield('metadesciption')">
    <meta property="og:image" content="{{asset('assets/image/og-image.png')}}">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css">
    
    <link rel="stylesheet" href="{{asset('assets/style/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/style/style.css')}}">
    <link rel="stylesheet" href="{{asset('assets/style/responsive.css')}}">
    <style>
        .section-not-found {
            padding: 0;
            height: auto;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .section-not-found img {
            max-width: 50%;
        }
        .icon-check {
            display: inline-block;
            height: 9vw;
            width: 9vw;
            background: linear-gradient(359deg, #FF5003 -3.44%, #004b8d 99.84%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 4vw auto 4vw;
            border-radius: 50%;
            font-size: 4vw;
            color: white;
            position: relative;
        }
        
        .icon-check:before,.icon-check:after {
            content: '';
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%,-50%);
            background: linear-gradient(359deg, #FF5003 -3.44%, #004b8d 99.84%);
            width: 100%;
            height: 100%;
            border-radius: 50%;
            z-index: -1;
            opacity: 0.2;
            animation: 3s scaleup infinite alternate;
            -webkit-animation: 3s scaleup infinite alternate;
            -ms-animation: 3s scaleup infinite alternate;
        }
        
        .icon-check:after {
            opacity: 0.3;
            animation-delay:3s;
        }
        
        @keyframes  scaleup{
            from{
                transform:translate(-50%,-50%) scale(1);
            }
            to{
                transform:translate(-50%,-50%) scale(1.3);
            }
        }
        
        @-webkit-keyframes scaleup{
            from{
                transform:translate(-50%,-50%) scale(1);
            }
            to{
                transform:translate(-50%,-50%) scale(1.3);
            }
        }
        
        @-ms-keyframes scaleup{
            from{
                transform:translate(-50%,-50%) scale(1);
            }
            to{
                transform:translate(-50%,-50%) scale(1.3);
            }
        }
    </style>
    <!-- Meta Pixel Code -->
    <!--    <script>-->
    <!--      !function(f,b,e,v,n,t,s)-->
    <!--      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?-->
    <!--      n.callMethod.apply(n,arguments):n.queue.push(arguments)};-->
    <!--      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';-->
    <!--      n.queue=[];t=b.createElement(e);t.async=!0;-->
    <!--      t.src=v;s=b.getElementsByTagName(e)[0];-->
    <!--      s.parentNode.insertBefore(t,s)}(window, document,'script',-->
    <!--      'https://connect.facebook.net/en_US/fbevents.js');-->
    <!--      fbq('init', '191886536580711');-->
    <!--      fbq('track', 'PageView');-->
    <!--    </script>-->
    <!--    <noscript><img height="1" width="1" style="display:none"-->
    <!--      src="https://www.facebook.com/tr?id=191886536580711&ev=PageView&noscript=1"-->
    <!--    /></noscript>-->
    <!-- End Meta Pixel Code -->
    
    <!-- Meta Pixel Code -->
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '964372911461249');
      fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=964372911461249&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Meta Pixel Code -->
    
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-KN2TZN6');</script>
    <!-- End Google Tag Manager -->
    
    </head>
    
    <body>
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KN2TZN6"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->
        <main>
            <section class="banner-section-services background-after-image-blurred section-not-found">
                <div class="before-image-banner position-relative">
                    <div class="container-1470 position-relative">
                        <div class="banner-flex">
                            <div class="banner-content-services mw-100">
                                <div>
                                    <a href="{{ URL::to('/') }}">
                                        <img src="{{asset('assets/image/logo.png')}}" alt="">
                                    </a>
                                    <h1 class="my-5">Thank You <br></h1>
                                    <p class="fa-18">Thank you for getting in touch with us. Our team will review your message and get back to you as soon as possible.
                                    <!--You can expect to hear from us shortly with further information or to schedule a follow-up discussion.-->
                                    </p>
                                    <span class="icon-check">
                        		        <i class="fa-solid fa-check"></i>
                        		    </span>
                                    <a class="btn-regular btn-weight-medium justify-content-center orange-btn px-3 text-center" href="{{ URL::to('/') }}">
                                        <span> Back To Home </span>
                                    </a>
                                    @include('socialicons')
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <!-- This site is converting visitors into subscribers and customers with https://respond.io --><script id="respondio__widget" src="https://cdn.respond.io/webchat/widget/widget.js?cId=92266f9d4e27f738ae45cbf4ae3385990c0ebbe985397807d3ea20d4915049a1"></script><!-- https://respond.io -->
    </body>

</html>


