@extends('front.app')

@section('title','Mobile App Marketing Agency To Optimize Your App Downloads')
@section('metadescription','Employ our mobile app marketing agency to increase the exposure and downloads of your app with our app marketing techniques and grow your audience.')
@section('keywords', 'app store seo,mobile app seo,social media optimization service,app marketing agency,mobile app marketing agency')
@section('content')








        <section class="banner-section-services background-after-image-blurred">
            <div class="before-image-banner position-relative">
                <a href="#sec2" class="secdown">
                <p>Scroll to explore</p>
                <span><img src="{{asset('assets/image/ArrowULeftDown.png')}}" alt=""></span>
            </a>
                <div class="container-1470 position-relative">
                    <div class="banner-flex">
                        <div class="image-banner-left image-banner">
                            <img src=" {{asset('assets/image/services/appdownloads/banner-bottom.png')}}" alt="">
                            <img class="abs-image-blur-abs" src="assets/image/services/appdownloads/banner-bottom.png" alt="">
                        </div>
                        <div class="banner-content-services">
                            <div>
                                <h1>App Marketing <br>Agency</h1>
                                <p>Ready to see your app grow in popularity and create a lasting impression on the app market? Increasing app downloads can be challenging. Our mobile app marketing agency makes it easier than ever to promote your app so you can stand out from the competition.</p>
                                <a class="btn-regular orange-btn btn-weight-medium" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                                @include('socialicons')
                            </div>
                        </div>
                        <div class="image-banner-right image-banner">
                            <img src=" {{asset('assets/image/services/appdownloads/banner-top.png')}}" alt="">
                            <img class="abs-image-blur-abs" src="{{asset('assets/image/services/appdownloads/banner-top.png')}}" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="info-service-page" id="sec2">
            <div class="container-1470">
                <div class="text-service-information">
                    <h4 class="fa-50">Raise your business to the top with App Downloads Service</h4>
                    <p class="fa-18">Don't let your app become lost in a sea of rivals. Allow us to be the driving force behind the success of your app. Our app marketing agency can assist you in reaching more people with our marketing and app promotion initiatives, which are intended to increase an app's visibility and downloads.</p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Planning & <br>Research</h4>
                                <div class="image-blurb-item">
                                    <img src=" {{asset('assets/image/services/appdownloads/planning-research.png')}}" alt="">
                                    <img class="abs-image-blur-abs" src="{{asset('assets/image/services/appdownloads/planning-research.png')}}" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Prior to promoting your app, we will research your competitors and market trends, identify the best promotional channels, and then plan promotional strategies to increase the likelihood of app downloads.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>App SEO</h4>
                                <div class="image-blurb-item">
                                    <img src=" {{asset('assets/image/services/appdownloads/mobile-app.png')}}" alt="">
                                    <img class="abs-image-blur-abs" src="{{asset('assets/image/services/appdownloads/mobile-app.png')}}" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>Optimizing your app will help you get more downloads. We will optimize your app store SEO with pertinent keywords to improve your visibility and increase your organic position.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Targeting</h4>
                                <div class="image-blurb-item">
                                    <img src=" {{asset('assets/image/services/appdownloads/targeting.png')}}" alt="">
                                    <img class="abs-image-blur-abs" src="{{asset('assets/image/services/appdownloads/targeting.png')}}" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>In order to target your promotional campaigns appropriately,we will analyse  audience's behaviour as for usage patterns, purchase histories, and engagement with comparable apps to increase the number of  app downloads.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Campaign <br>Execution</h4>
                                <div class="image-blurb-item">
                                    <img src=" {{asset('assets/image/services/appdownloads/video-ads.png')}}" alt="">
                                    <img class="abs-image-blur-abs" src="{{asset('assets/image/services/appdownloads/video-ads.png')}}" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>In order to successfully execute a promotional campaign that reaches your target audience, our social media optimization service will develop flexible and adaptable promotional strategies with careful planning and clear goals in mind.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-blurb small-blurb">
                            <div class="item-blurb-header">
                                <h4>Downloads</h4>
                                <div class="image-blurb-item">
                                    <img src=" {{asset('assets/image/services/appdownloads/download.png')}}" alt="">
                                    <img class="abs-image-blur-abs" src="{{asset('assets/image/services/appdownloads/download.png')}}" alt="">
                                </div>
                            </div>
                            <div class="item-blurb-main">
                                <p>We could therefore increase your app's visibility and downloads by implementing strategic approaches, optimizing mobile app SEO, and tracking the effectiveness of the campaign, which will ultimately result in the success of your mobile app.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="tools-technology">
            <div class="container-1470">
                <div class="text-service-information">
                    <h4 class="fa-50">Tools and technologies deployed for App Downloads Service</h4>
                    <p class="fa-18">To generate awareness about your app, we use the power of app store optimization, attractive app previews, and targeted advertising campaigns. Leveraging targeted ads on different social media platforms to connect with your target market and persuade them to download your app.</p>
                </div>
                <div class="tools-icons icons-6">
                    <img class="max-200-img" src=" {{asset('assets/image/services/trafficoptimization/meta.png')}}" alt="">
                    <img src=" {{asset('assets/image/services/trafficoptimization/ads.png')}}" alt="">
                    <img src=" {{asset('assets/image/services/leadgeneration/tiktok.png')}}" alt="">
                    <img src=" {{asset('assets/image/services/appdownloads/appstore.png')}}" alt="">
                    <img src=" {{asset('assets/image/services/appdownloads/playstore.png')}}" alt="">
                </div>
            </div>
        </section>

        <section class="experience-text col-mb-30">
            <div class="container-1470">

                <div class="text-service-information">
                    <h4 class="fa-50">App Downloads: <br>Proven way of digital success</h4>
                    <p class="fa-18">Witness your app's popularity increase and create a lasting impression on the app market! The more downloads and promotions your app has, the more likely it is to be viewed as a significant feature by potential clients.</p>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience heading-simple">
                            <h4 class="bg-gradient-blue">Social Media Promotion</h4>
                            <p>A potent tool for app promotion is social media. We will establish your social media presence which you can use to interact with users, share updates, and advertise new features.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience heading-simple">
                            <h4 class="bg-gradient-orange">Advertisement</h4>
                            <p>Paid advertising on different platforms is also an efficient way to reach a larger audience and encourage app downloads and build targeted campaigns that connect with your target market.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience heading-simple">
                            <h4 class="bg-gradient-blue">Collaboration</h4>
                            <p>Working with endorsers to promote your business who have a significant following among the potential users of your app has been very successful for businesses in increasing sales and app downloads</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience heading-simple">
                            <h4 class="bg-gradient-orange">User Engagement</h4>
                            <p>Engaging with your users on social media and in-app messaging will help us in developing a base of devoted users and raise the possibility of app recommendations and favourable reviews.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience heading-simple">
                            <h4 class="bg-gradient-blue">Analytics Deployment</h4>
                            <p>We employ analytics tools to monitor and evaluate your marketing initiatives and then utilizing that information to enhance the performance of your app and your marketing campaigns.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="items-experience heading-simple">
                            <h4 class="bg-gradient-orange">Adaptable Tactics</h4>
                            <p>We remain versatile, stay active, and keep improving the effectiveness of your marketing campaigns to meet your goals on the basis of the data and insights generated by research and tools.</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <section class="pricing-services">
            <div class="container-1470">
                <div class="text-pricing">
                    <h4>Monthly Retainer <br> Plans</h4>
                    <p class="mx-663">With our monthly retainer plan, you can rest assured that your company is in the hands of knowledgeable professionals.</p>
                </div>
                <div class="package-main-services">
                    <div class="main-parent-services-packages">
                        <div class="row-services-packages">
                            <div class="col-first-packages">
                                <h3>Deliverables</h3>
                                <ul class="features-li line-before">
                                    <li>Research and planning</li>
                                    <li>Social Accounts Creation</li>
                                    <li>Facebook & Instagram Posting </li>
                                    <li>App SEO</li>
                                    <li>Video creation Ad</li>
                                    <li>Ad Type</li>
                                    <li>Platforms</li>
                                    <li>Paid Campaigns </li>
                                    <li>Ad Budget Included</li>
                                    <li>Number of downloads</li>
                                    <li>Monthly Reports</li>
                                    <li class="pricing">Price</li>
                                </ul>
                            </div>
                            <div class="col-second-packages">
                                <div class="row-services-packages">
                                    <div class="packages-all packages-basic active-pricing">
                                        <h3>Basic</h3>
                                        <ul>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>8</li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li><i class="fa fa-times-circle"></i></li>
                                            <li> Image </li>
                                            <li>FB/Insta</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>1000</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li class="pricing-packages">
                                                <p class="same-font-sizing">$5,999</p>
                                            </li>
                                        </ul>
                                        <div class="packages-btn">
                                            <button class="btn-regular orange-btn btn-weight-medium" data-bs-toggle="modal" data-bs-target="#getstarted">
                                                <span> Get Started </span>
                                                <span class="icon-arrow-image">
                                                    <i class="fa-solid fa-arrow-right"></i>
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="packages-all packages-pro">
                                        <h3>Pro</h3>
                                        <ul>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>12</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>30 Sec</li>
                                            <li>Image, Video</li>
                                            <li>FB/Insta</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>2000</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li class="pricing-packages">
                                                <p class="same-font-sizing">$11,999</p>
                                            </li>
                                        </ul>
                                        <div class="packages-btn">
                                            <button class="btn-regular orange-btn btn-weight-medium" data-bs-toggle="modal" data-bs-target="#getstarted">
                                                <span> Get Started </span>
                                                <span class="icon-arrow-image">
                                                    <i class="fa-solid fa-arrow-right"></i>
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="packages-all packages-custom">
                                        <h3>Custom</h3>
                                        <ul>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>30</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>60 Sec</li>
                                            <li>Image & Video</li>
                                            <li>FB/Insta/Google</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li>-</li>
                                            <li><i class="fa fa-check-circle"></i></li>
                                            <li class="pricing-packages quote-price">
                                                <button class="btn-regular orange-btn btn-weight-medium btn-weight-medium-blue" data-bs-toggle="modal" data-bs-target="#getstarted">
                                                    <span>Get A Quote</span>
                                                    <span class="icon-arrow-image">
                                                        <i class="fa-solid fa-arrow-right"></i>
                                                    </span>
                                                </button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


@endsection