<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title property="title">404 Not Found - CROXpertz</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta property="description" name="description" content="@yield('metadesciption')">
    <meta name="keywords" content="CROxpertz">
    
    
    <!-- <meta name="robots" content="index, follow"> -->
    <link rel="icon" href="assets/image/fav-icon.png" type="image/x-icon">
    <meta property="og:site_name" content="CROXpertz">
    <meta property="og:title" content="CROXpertz">
    <meta property="og:description" content="@yield('metadesciption')">
    <meta property="og:image" content="{{asset('assets/image/og-image.png')}}">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css">
    
    <link rel="stylesheet" href="{{asset('assets/style/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/style/style.css')}}">
    <link rel="stylesheet" href="{{asset('assets/style/responsive.css')}}">
    <style>
        .section-not-found {
            padding: 0;
            height: auto;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .section-not-found img {
            max-width: 50%;
        }
    </style>
    <body>
        <main>
            <section class="banner-section-services background-after-image-blurred section-not-found">
                <div class="before-image-banner position-relative">
                    <div class="container-1470 position-relative">
                        <div class="banner-flex">
                            <div class="banner-content-services">
                                <div>
                                    <a href="{{ URL::to('/') }}">
                                        <img src="{{asset('assets/image/logo.png')}}" alt="">
                                    </a>
                                    <h1 class="my-5">Page <br> Not Found</h1>
                                    <a class="btn-regular btn-weight-medium justify-content-center orange-btn px-3 text-center" href="{{ URL::to('/') }}">
                                        <span> Back To Home </span>
                                    </a>
                                    @include('socialicons')
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    </body>

</html>


