@extends('front.app')

@section('title','Privacy Policy')
@section('metadescription','')
@section('keywords', '')
@section('content')


        <section class="banner-section-services background-after-image-blurred banner-privacy">
            <div class="before-image-banner position-relative">
                <a href="#sec2" class="secdown">
                    <p>Scroll to explore</p>
                    <span><img src="{{asset('assets/image/ArrowULeftDown.png')}}" alt=""></span>
                </a>
                <div class="container-1470 position-relative">
                    <div class="banner-flex">
                        <div class="image-banner-left image-banner">
                            <img src=" {{asset('assets/image/privacy3.png')}}" alt="">
                        </div>
                        <div class="banner-content-services">
                            <div>
                                <h1>Privacy <br>Policy</h1>
                                <p>At CROxpertz's, we take your privacy very seriously. This Privacy Policy outlines the types of information we collect, how we use it, and how we protect your personal information.</p>
                                <a class="btn-regular orange-btn btn-weight-medium" href="#" data-bs-toggle="modal" data-bs-target="#getstarted">
                                    <span> Get Started </span>
                                    <span class="icon-arrow-image">
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </span>
                                </a>
                                @include('socialicons')
                            </div>
                        </div>
                        <div class="image-banner-right image-banner">
                            <img src=" {{asset('assets/image/privacy2.png')}}" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="sec2" class="pptcrf">
            <div class="container-1470">
                <div class="wrapping">
                    <h2 class="mb-20 fa-50">General</h2>
                    <p class="fa-18 mb-20">This Privacy Policy describes how “CRO Xpertz” (“Company” or “we” hereby) collects uses and shares information provided by you when you visit our website located at https://www.croxpertz.com or use any of our services.</p>
                    <p class="fa-18 mb-20">This policy also informs you about your rights as visitors or viewers of our website with respect to your Personal data and how you can get your questions answered about your Personal data and our Privacy Policy.</p>
                    <p class="fa-18 mb-20">We own the rights to change our Privacy Policy anytime in the future. If we change the Policy, we will update it in this section of our website along with the date of revision.</p>
                    <p class="fa-18 mb-20">When you visit our site or any of our services, you become subject to our Privacy Policy. You agree to our collection and use of your Personal Data and any other information. We use the data collected from our website according to the laws and regulations of collecting, sharing, using and transmitting of your Personal and non-Personal Data.</p>
                    <p class="fa-18 mb-20">Please read our Privacy Policy and our Cookie Policy thoroughly and if you have any questions pertaining to it, please feel free to contact us through the contact information given at the bottom of the page. </p>
                    <h2 class=" mb-20 fa-50 pdt-50">Whose personal data do we process?</h2>
                    <p class="fa-18 mb-20">We can process your personal data if:</p>
                    <p class="fa-18 mb-20">You are a visitor, client or vendor of CRO. (or are interested in becoming one);</p>
                    <p class="fa-18 mb-20">You use our products and/or our services;</p>
                    <p class="fa-18 mb-20">You work for our client and/or vendor, or someone who uses services and/or products that have been developed by us;</p>
                    <p class="fa-18 mb-20">You are a client (or work for a client), who we want to tell about and offer our services and/or products; </p>
                    <p class="fa-18 mb-20">You are our employee, subcontractor, or are interested in working with us. </p>
                    <h2 class="mb-20 fa-50 pdt-50">What kind of personal information do we collect?</h2>
                    <p class="fa-18 mb-20">We collect personal data and other information provided to us either by you or by a third party.</p>
                    <p class="fa-18 mb-20">This information can include:</p>
                    <p class="fa-18 mb-20">Your name;</p>
                    <p class="fa-18 mb-20">Information about your employer, subdivision, and official duties;</p>
                    <p class="fa-18 mb-20">our address, phone number, email address, or any other contact details;</p>
                    <p class="fa-18 mb-20">Personal information given to us during phone conversations, email correspondence, the use of our website (information gathered when you register to receive newsletters; place an order; participate in a contest, advertising campaign, or survey; form submits when you are reporting a problem);</p>
                    <p class="fa-18 mb-20">Information regarding any cooperation between CRO and you or your employer (such as requesting specifications for products we’ve developed and/or services we have provided to you or your employer);</p>
                    <p class="fa-18 mb-20">Other personal information includes;</p>
                    <ul class="fa-18 for-list mb-20">
                        <li>Technical information including the IP address which you use to connect to the Internet;</li>
                        <li>Your registration information;</li>
                        <li>The type and version of your browser;</li>
                        <li>Your time-zone;</li>
                        <li>Your operating system and platform;</li>
                        <li>Information about your visit, including visited URLs;</li>
                        <li>Your browsing history across our website;</li>
                        <li>Information about the time and date when you visited our website;</li>
                        <li>Services and pages that you saw and searched for;</li>
                        <li>Time spent on each page;</li>
                        <li>Page response time;</li>
                        <li>Information on your activities on any page of our website (such as scrolling and mouse clicks or hovers);</li>
                        <li>Ways in which you landed on pages as well as the phone number or social buttons you used to get in touch with us.</li>
                    </ul>
                       <p class="fa-18 mb-20 "> If you provide CRO with data of/from third parties (such as their names, email addresses, phone numbers, etc.), you guarantee that you have the rights to do so. In certain cases, CRO and partner third-parties can automatically collect data using browser cookies, web logs, web beacons, and other similar applications and attachments.</p>
                    <h2 class="mb-20 fa-50 pdt-50">What we do with your personal information</h2>
                    <p class="fa-18 mb-20">We process your personal information for the following reasons:</p>
                    <p class="fa-18 mb-20">Advertising and sales activities as well as presenting information about our services and products (in ways that we determine ourselves);</p>
                    <p class="fa-18 mb-20">Creating and executing contracts and agreements with you or your employer to:</p>
                    <p class="fa-18 mb-20">Provide services to clients and other users of these services;</p>
                    <p class="fa-18 mb-20">Receive goods and services from vendors;</p>
                    <p class="fa-18 mb-20">Internal processing, including fixes of defects, data analysis, testing, and collecting data for surveys;</p>
                    <p class="fa-18 mb-20">Improving our website to provide content in the most effective way for you and the device you are using;</p>
                    <p class="fa-18 mb-20">Evaluation and understanding of the efficiency of the advertising that we display to you and other parties as well as displaying relevant advertising;</p>
                    <p class="fa-18 mb-20">Providing tips and recommendations on services which could be interesting to you or your employer in accordance with your preferences (where applicable). </p>
                    <p class="fa-18 mb-20">We can share your personal data with:</p>
                    <h2 class="mb-20 fa-50 pdt-50">To whom do we disclose your personal information</h2>
                    <p class="fa-18 mb-20">Any member of our company, including subsidiaries, affiliated companies.</p>
                    <p class="fa-18 mb-20">Third parties, including:</p>
                    <p class="fa-18 mb-20">Our business partners, clients, vendors, and subcontractors;</p>
                    <p class="fa-18 mb-20">Our auditors, legal consultants, and other professional consultants or</p>
                    <p class="fa-18 mb-20">We can share data collected via our website with:</p>
                    <p class="fa-18 mb-20">Our advertisers and advertising networks which need this data to select and display relevant ads to you and others. We do not disclose any data that can personally identify you to advertisers, but we do provide general data about our users. We can also use this general data to help advertisers display ads to our target audience. We can use your personal data to demonstrate ads of our advertisers and their target audience.</p>
                    <p class="fa-18 mb-20">To protect the rights, property, and security of CRO, our clients, our employees, and other users. This includes sharing information with other companies and organizations (including law enforcement) with the goal of preventing fraud and other risks.</p>
                    <h2 class="mb-20 fa-50 pdt-50">Usage of outbound links</h2>
                    <p class="fa-18 mb-20">CRO websites might include links that lead to other websites, websites that are controlled by parties we are not related or connected to. After clicking an outbound link we lose any control of collection, storage, or processing of your personal data that is transferred </p>
                    
                    

                

                </div>
                </div>
              
              

        </section>


@endsection