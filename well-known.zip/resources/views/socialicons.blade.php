<div class="social-banner @yield('social-icon-main')">
    <a href="https://www.facebook.com/profile.php?id=100091206667713">
        <img src="{{asset('assets/image/social/fb.png')}}" alt="">
        <span>Facebook</span>
    </a>
    <a href="https://www.instagram.com/croxpertz/">
        <img src="{{asset('assets/image/social/insta.png')}}" alt="">
        <span>Instagram</span>
    </a>
    <!--<a href="#">-->
    <!--    <img src="{{asset('assets/image/social/twitter.png')}}" alt="">-->
    <!--    <span>Twitter</span>-->
    <!--</a>-->
</div>